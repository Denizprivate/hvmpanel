#!/bin/bash

set -e

echo "========================================="
echo "Docker Panel Installer"
echo "========================================="

echo "[1/8] Updating package lists..."
apt-get update -y

echo "[2/8] Installing required packages..."
apt-get install -y \
    curl \
    wget \
    git \
    python3 \
    python3-pip \
    python3-venv \
    jq \
    ufw \
    fail2ban \
    apt-transport-https \
    ca-certificates \
    gnupg \
    lsb-release \
    software-properties-common

echo "[3/8] Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    usermod -aG docker $USER
    echo "Docker installed successfully"
else
    echo "Docker already installed"
fi

echo "[4/8] Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo "Docker Compose installed"
else
    echo "Docker Compose already installed"
fi

echo "[5/8] Installing Python dependencies..."
pip3 install --break-system-packages \
    flask \
    flask-login \
    flask-socketio \
    flask-sqlalchemy \
    werkzeug \
    requests \
    paramiko \
    pillow \
    hypercorn \
    asgiref

echo "[6/8] Setting up firewall..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 3000/tcp
ufw --force enable

echo "[7/8] Creating necessary directories..."
mkdir -p static/uploads/settings
mkdir -p static/uploads/profiles
mkdir -p static/uploads/os_icons

echo "[8/8] Setting permissions..."
chmod +x *.py
chmod +x *.sh
chmod -R 755 static/
chmod -R 755 templates/

echo "========================================="
echo "Installation complete!"
echo "========================================="
echo ""
echo "To start the panel:"
echo "  python3 lvm.py"
echo ""
echo "Or use the included service:"
echo "  cp dockerpanel.service /etc/systemd/system/"
echo "  systemctl enable dockerpanel"
echo "  systemctl start dockerpanel"
echo ""
echo "Default login: admin / admin"
echo "========================================="