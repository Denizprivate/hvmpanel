# 🚀 Supra Hosting Panel v1.0

High-performance VPS management panel with Discord bot integration.

## 📦 Quick Install

```bash
# 1. Upload this folder to your server
# 2. Run the installer as root
sudo bash install.sh
```

**License Key:** `LVM-8F3K2-9XQPL-4Z7MN`

---

## ✅ What Gets Installed

| Component | Details |
|-----------|---------|
| **LXC/LXD** | Container management |
| **Docker + Sysbox** | Docker-in-Docker support (ubuntu-dind) |
| **Flask Panel** | Web UI on port **8888** |
| **Discord Bot** | Full panel API integration |

---

## 🌐 Panel Access

After installation:
- **URL:** `http://YOUR_SERVER_IP:8888`
- **Username:** `admin`
- **Password:** `admin`

> ⚠️ **Change your password immediately after first login!**

---

## 🤖 Discord Bot Commands

| Command | Description |
|---------|-------------|
| `/create lxc` | Create LXC container |
| `/create docker` | Create Docker (ubuntu-dind) container |
| `/list` | List your VPS |
| `/vps start/stop/restart/delete <name>` | Control VPS |
| `/ssh <name>` | Get tmate + sshx links |
| `/status` | Node health stats |
| `/invites` | Check invite stats |
| `/panel` | Get panel URL |
| `/admincreate @user` | *(Admin)* Create VPS for user |
| `/listall` | *(Admin)* All VPS on panel |
| `/panelusers` | *(Admin)* All panel users |
| `/announce <msg>` | *(Admin)* Broadcast message |

---

## 🎨 Panel Features

- **10+ built-in gradient wallpapers** + custom image/video upload
- **Glassmorphism UI** — smooth dark blue theme
- **Animated splash screen** on first load
- **Real-time stats** — live CPU/RAM bars per VPS
- **Web SSH console** — in-browser terminal via WebSocket
- **tmate + sshx** session generation with one click
- **LXC containers** — full lifecycle management
- **Docker VPS** — ubuntu-dind with Sysbox runtime
- **Multi-node** cluster support
- **Discord OAuth** login
- **Port forwarding** management
- **Expiry system** with auto-suspend
- **Database backups** with download/restore
- **Admin panel** — users, all VPS, nodes, OS icons, system info, logs, maintenance

---

## 🔧 Services

```bash
# Panel
systemctl status supra-panel
systemctl restart supra-panel
journalctl -u supra-panel -f

# Bot
systemctl status supra-bot
systemctl restart supra-bot
journalctl -u supra-bot -f
```

---

## 🔑 API

All endpoints require the header: `X-API-Key: <your-admin-key>`

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/status` | Panel status |
| GET | `/api/v1/vps` | List VPS |
| POST | `/api/v1/vps/create` | Create VPS |
| POST | `/api/v1/vps/{id}/action` | start/stop/restart/delete |
| GET | `/api/v1/nodes` | List nodes |
| GET | `/api/v1/users` | List users (admin) |

---

## 📁 File Structure

```
supra-panel/
├── install.sh          ← Run this first!
├── panel/
│   ├── run.py          ← Entry point
│   ├── requirements.txt
│   └── app/
│       ├── __init__.py
│       ├── models.py
│       ├── routes/     ← auth, main, vps, admin, api, ws
│       └── templates/  ← All HTML templates
└── bot/
    ├── bot.py          ← Discord bot
    └── requirements.txt
```

---

*Powered by Supra Hosting © 2026 | Version 1.0*
