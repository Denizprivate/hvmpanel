"""
Supra Hosting — Discord Bot v2.0
Full panel integration via REST API
"""
import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio, aiohttp, os, secrets, string, psutil, json
from datetime import datetime
from dotenv import load_dotenv
from tinydb import TinyDB, Query

load_dotenv()

# ── CONFIG ────────────────────────────────────────────────────────────────────
TOKEN          = os.getenv('BOT_TOKEN', '')
ADMIN_IDS      = [int(x) for x in os.getenv('ADMIN_IDS', '0').split(',') if x]
ADMIN_LOG_CH   = int(os.getenv('ADMIN_LOG_CHANNEL', 0))
PUBLIC_LOG_CH  = int(os.getenv('PUBLIC_LOG_CHANNEL', 0))
PANEL_URL      = os.getenv('PANEL_URL', 'http://localhost:8888').rstrip('/')
PANEL_API_KEY  = os.getenv('PANEL_API_KEY', '')
PREFIX         = os.getenv('PREFIX', '!')
IMAGE_NAME     = os.getenv('IMAGE_NAME', 'ubuntu:22.04')

# Local DB for invite tracking
inv_db = TinyDB('invites.json')
invites_table = inv_db.table('invites')
members_table = inv_db.table('members')
User = Query()

invites_cache = {}

# ── INTENTS & BOT ────────────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.invites = True

bot = commands.Bot(command_prefix=[PREFIX, '-'], intents=intents, help_command=None)

# ── PANEL API ─────────────────────────────────────────────────────────────────
async def panel_api(method: str, endpoint: str, data: dict = None):
    url = f"{PANEL_URL}/api/v1/{endpoint.lstrip('/')}"
    headers = {'X-API-Key': PANEL_API_KEY, 'Content-Type': 'application/json'}
    async with aiohttp.ClientSession() as s:
        func = getattr(s, method.lower())
        kwargs = {'headers': headers}
        if data: kwargs['json'] = data
        try:
            async with func(url, **kwargs) as r:
                return await r.json()
        except Exception as e:
            return {'error': str(e)}

# ── HELPERS ───────────────────────────────────────────────────────────────────
def run_cmd(cmd):
    import subprocess
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
    return r.stdout.strip(), r.stderr.strip(), r.returncode

async def arun(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, err = await proc.communicate()
    return out.decode().strip(), err.decode().strip(), proc.returncode

async def send_log(title, desc, color, pub_title=None, pub_desc=None, pub_color=None):
    admin_ch = bot.get_channel(ADMIN_LOG_CH)
    if admin_ch:
        await admin_ch.send(embed=discord.Embed(title=title, description=desc, color=color,
                                                 timestamp=datetime.utcnow()))
    if pub_title and bot.get_channel(PUBLIC_LOG_CH):
        await bot.get_channel(PUBLIC_LOG_CH).send(
            embed=discord.Embed(title=pub_title, description=pub_desc, color=pub_color,
                                timestamp=datetime.utcnow()))

def blue_embed(title='', desc='', fields=None):
    e = discord.Embed(title=title, description=desc, color=0x3b82f6, timestamp=datetime.utcnow())
    if fields:
        for name, val, inline in fields:
            e.add_field(name=name, value=val, inline=inline)
    e.set_footer(text='Supra Hosting', icon_url='')
    return e

# ── EVENTS ───────────────────────────────────────────────────────────────────
@bot.event
async def on_ready():
    print('═' * 50)
    print(f'  ✅  Supra Bot Online: {bot.user.name}')
    print(f'  🔗  Gateway ID      : {bot.user.id}')
    print(f'  🌐  Panel URL       : {PANEL_URL}')
    print('═' * 50)
    for guild in bot.guilds:
        try: invites_cache[guild.id] = await guild.invites()
        except: pass
    try: await bot.tree.sync()
    except: pass
    stats_updater.start()

@bot.event
async def on_invite_create(invite):
    try: invites_cache[invite.guild.id] = await invite.guild.invites()
    except: pass

@bot.event
async def on_member_join(member):
    guild = member.guild
    old = invites_cache.get(guild.id, [])
    try: new = await guild.invites()
    except: return
    used = next((i for o in old for i in new if o.code == i.code and i.uses > o.uses), None)
    invites_cache[guild.id] = new
    existing = members_table.get(User.member_id == str(member.id))
    if existing: return
    if used and used.inviter:
        inv = invites_table.get(User.id == str(used.inviter.id)) or \
              {'id': str(used.inviter.id), 'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
        age_days = (discord.utils.utcnow() - member.created_at).days
        if age_days < 7: inv['fakes'] += 1
        else: inv['joins'] += 1
        invites_table.upsert(inv, User.id == str(used.inviter.id))
        members_table.upsert({'member_id': str(member.id), 'inviter_id': str(used.inviter.id)}, User.member_id == str(member.id))

@bot.event
async def on_member_remove(member):
    rec = members_table.get(User.member_id == str(member.id))
    if rec:
        inv = invites_table.get(User.id == rec['inviter_id'])
        if inv: inv['leaves'] += 1; invites_table.upsert(inv, User.id == rec['inviter_id'])

# ── BACKGROUND TASKS ─────────────────────────────────────────────────────────
@tasks.loop(minutes=5)
async def stats_updater():
    """Periodically update node stats on the panel"""
    pass  # Panel handles its own polling

# ── HELP COMMAND ─────────────────────────────────────────────────────────────
class HelpSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label='Server Management', emoji='🚀', description='Deploy, delete, list servers'),
            discord.SelectOption(label='Power Actions', emoji='⚡', description='Start, stop, restart'),
            discord.SelectOption(label='Access & Info', emoji='🔐', description='SSH, console links'),
            discord.SelectOption(label='Invites & Stats', emoji='📊', description='Invite tracking'),
            discord.SelectOption(label='Admin Panel', emoji='🛠️', description='Admin only commands'),
        ]
        super().__init__(placeholder='Select a category...', min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        v = self.values[0]
        e = discord.Embed(title=f'Supra Hosting Help — {v}', color=0x3b82f6, timestamp=datetime.utcnow())
        if v == 'Server Management':
            e.add_field(name='Commands', value=
                '`/create <type> [name]` — Deploy a new server (LXC/Docker)\n'
                '`/delete [name]` — Delete a server\n'
                '`/list` — List your servers\n'
                '`/rebuild [name]` — Wipe and reinstall\n'
                '`/status` — Node stats', inline=False)
        elif v == 'Power Actions':
            e.add_field(name='Commands', value=
                '`/start [name]` — Start server\n'
                '`/stop [name]` — Stop server\n'
                '`/restart [name]` — Restart server', inline=False)
        elif v == 'Access & Info':
            e.add_field(name='Commands', value=
                '`/ssh [name]` — Generate tmate + sshx links\n'
                '`/info [name]` — Server details\n'
                '`/panel` — Get panel link', inline=False)
        elif v == 'Invites & Stats':
            e.add_field(name='Commands', value=
                '`/invites [@user]` — View invite stats', inline=False)
        elif v == 'Admin Panel':
            if interaction.user.id in ADMIN_IDS:
                e.add_field(name='Commands', value=
                    '`/admincreate <user> <cpu> <ram> <disk> [name]` — Create VPS for user\n'
                    '`/admindelete <name>` — Force delete any VPS\n'
                    '`/lookup <user>` — View user servers on panel\n'
                    '`/suspend <user>` — Suspend user\n'
                    '`/unsuspend <user>` — Restore user\n'
                    '`/announce <msg>` — Broadcast\n'
                    '`/listall` — List all VPS on panel\n'
                    '`/panelusers` — List all panel users\n'
                    '`/nodestatus` — Check node health', inline=False)
            else:
                e.description = '*You do not have admin permissions.*'
        e.set_footer(text='Supra Hosting Bot v2.0')
        await interaction.response.edit_message(embed=e)

class HelpView(discord.ui.View):
    def __init__(self): super().__init__(); self.add_item(HelpSelect())

@bot.hybrid_command(description='Show help menu')
async def help(ctx):
    e = discord.Embed(title='Supra Hosting', description='Select a category below.\n\n-# Full VPS management right from Discord.',
                      color=0x3b82f6, timestamp=datetime.utcnow())
    e.set_footer(text='Supra Hosting Bot v2.0')
    await ctx.send(embed=e, view=HelpView(), ephemeral=True)

# ── VPS COMMANDS ─────────────────────────────────────────────────────────────
@bot.hybrid_command(description='Create a VPS via the panel')
@app_commands.describe(vps_type='lxc or docker', name='Custom hostname (optional)', cpu='CPU cores', ram='RAM in GB', disk='Disk in GB')
async def create(ctx, vps_type: str = 'lxc', name: str = None, cpu: int = 2, ram: int = 2, disk: int = 20):
    if vps_type not in ('lxc', 'docker'):
        await ctx.send(embed=discord.Embed(description='Type must be `lxc` or `docker`.', color=0xef4444), ephemeral=True)
        return

    msg = await ctx.send(embed=blue_embed('🚀 Creating VPS...', f'Deploying `{vps_type.upper()}` — {cpu} cores / {ram}GB RAM / {disk}GB disk'), ephemeral=True)

    # Find or create panel user
    data = {
        'name': name or f'vps-{ctx.author.name.lower()[:10]}-{"".join(secrets.choice(string.ascii_lowercase+string.digits) for _ in range(4))}',
        'type': vps_type,
        'cpu': cpu, 'ram': ram, 'disk': disk,
        'owner_id': 1,  # Panel admin creates it; assign manually or via lookup
    }

    r = await panel_api('POST', 'vps/create', data)
    if r.get('ok'):
        vps_id = r.get('vps_id')
        vps_name = r.get('name')

        e = discord.Embed(title='✅ VPS Created!', color=0x10b981, timestamp=datetime.utcnow())
        e.add_field(name='Name', value=f'`{vps_name}`', inline=True)
        e.add_field(name='Type', value=vps_type.upper(), inline=True)
        e.add_field(name='Resources', value=f'{cpu} cores / {ram}GB RAM / {disk}GB', inline=True)
        e.add_field(name='Panel', value=f'[View on Panel]({PANEL_URL}/vps/)', inline=False)
        e.set_footer(text=f'VPS ID: {vps_id}')
        await msg.edit(embed=e)
        await ctx.author.send(embed=e)

        await send_log('Admin Log: VPS Created via Bot',
            f'**User:** {ctx.author.mention}\n**VPS:** `{vps_name}`\n**Type:** {vps_type}\n**Resources:** {cpu}c/{ram}GB/{disk}GB',
            0x10b981, '🚀 New VPS Deployed!',
            f'{ctx.author.mention} deployed a **{vps_type.upper()}** server via Discord!', 0x10b981)
    else:
        await msg.edit(embed=discord.Embed(title='❌ Creation Failed',
            description=r.get('error', 'Unknown error. Check panel logs.'), color=0xef4444))

@bot.hybrid_command(description='List your VPS instances from the panel')
async def list(ctx):
    r = await panel_api('GET', 'vps')
    if 'error' in r:
        await ctx.send(embed=discord.Embed(description=f'Error: {r["error"]}', color=0xef4444), ephemeral=True)
        return
    if not r:
        await ctx.send(embed=discord.Embed(description='No VPS instances found.', color=0x3b82f6), ephemeral=True)
        return
    e = discord.Embed(title='Your VPS Instances', color=0x3b82f6, timestamp=datetime.utcnow())
    for vps in r[:10]:
        status_emoji = '🟢' if vps['status'] == 'running' else '🔴' if vps['status'] == 'stopped' else '🟡'
        e.add_field(name=f'{status_emoji} {vps["name"]}',
                    value=f'ID: `{vps["id"]}` | {vps["cpu"]}c/{vps["ram"]}GB | {vps["status"]}',
                    inline=False)
    e.add_field(name='🌐 Panel', value=f'[Open Panel]({PANEL_URL}/vps/)', inline=False)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(description='Perform action on a VPS')
@app_commands.describe(action='start/stop/restart/delete', name='VPS name or ID')
async def vps(ctx, action: str, name: str):
    if action not in ('start', 'stop', 'restart', 'delete'):
        await ctx.send(embed=discord.Embed(description='Action must be: start, stop, restart, delete', color=0xef4444), ephemeral=True)
        return

    # Find VPS ID from name
    vps_list = await panel_api('GET', 'vps')
    target = next((v for v in vps_list if v['name'] == name or str(v['id']) == name), None)
    if not target:
        await ctx.send(embed=discord.Embed(description=f'VPS `{name}` not found.', color=0xef4444), ephemeral=True)
        return

    msg = await ctx.send(embed=blue_embed(f'⚡ {action.title()}ing VPS...', f'`{target["name"]}`'), ephemeral=True)
    r = await panel_api('POST', f'vps/{target["id"]}/action', {'action': action})

    if r.get('ok'):
        await msg.edit(embed=discord.Embed(title=f'✅ VPS {action.title()}ed', description=f'`{target["name"]}` — {r.get("status", "")}', color=0x10b981))
        await send_log(f'Bot: VPS {action.title()}', f'**User:** {ctx.author.mention}\n**VPS:** `{target["name"]}`', 0x3b82f6)
    else:
        await msg.edit(embed=discord.Embed(description=f'Action failed: {r.get("error","Unknown")}', color=0xef4444))

@bot.hybrid_command(description='Get SSH session links for a VPS')
@app_commands.describe(name='VPS name or ID')
async def ssh(ctx, name: str = None):
    vps_list = await panel_api('GET', 'vps')
    if not vps_list or 'error' in vps_list:
        await ctx.send(embed=discord.Embed(description='Could not fetch VPS list.', color=0xef4444), ephemeral=True)
        return
    if name:
        target = next((v for v in vps_list if v['name'] == name or str(v['id']) == name), None)
    elif len(vps_list) == 1:
        target = vps_list[0]
    else:
        names = '\n'.join([f'`{v["name"]}` (ID: {v["id"]})' for v in vps_list[:10]])
        await ctx.send(embed=discord.Embed(description=f'Specify a VPS name:\n{names}', color=0xf59e0b), ephemeral=True)
        return
    if not target:
        await ctx.send(embed=discord.Embed(description=f'VPS not found.', color=0xef4444), ephemeral=True)
        return

    msg = await ctx.send(embed=blue_embed('🔑 Generating SSH Sessions...', 'Installing tmate & sshx, this may take 30s...'), ephemeral=True)

    # Use LXC directly if running locally
    hostname = target['name'] if 'hostname' not in target else target.get('hostname', target['name'])
    out_t, _, _ = await arun(f"lxc exec {hostname} -- cat /root/tmate_link.txt 2>/dev/null")
    out_s, _, _ = await arun(f"lxc exec {hostname} -- grep -o 'https://sshx.io[^ ]*' /root/sshx.log 2>/dev/null")

    if not out_t and not out_s:
        # Install and generate
        await arun(f"lxc exec {hostname} -- bash -c 'apt-get install -y -qq tmate > /dev/null 2>&1 && tmate -S /tmp/ts new-session -d && sleep 2 && tmate -S /tmp/ts display -p \'#{{tmate_ssh}}\' > /root/tmate_link.txt 2>&1 &'")
        await arun(f"lxc exec {hostname} -- bash -c 'curl -sSf https://sshx.io/get | sh -s -- -q && sshx > /root/sshx.log 2>&1 &'")
        await asyncio.sleep(5)
        out_t, _, _ = await arun(f"lxc exec {hostname} -- cat /root/tmate_link.txt 2>/dev/null")
        out_s, _, _ = await arun(f"lxc exec {hostname} -- grep -o 'https://sshx.io[^ ]*' /root/sshx.log 2>/dev/null")

    e = discord.Embed(title=f'🔑 SSH Sessions — {target["name"]}', color=0x3b82f6, timestamp=datetime.utcnow())
    if out_t: e.add_field(name='tmate', value=f'```{out_t}```', inline=False)
    else: e.add_field(name='tmate', value='Not available', inline=False)
    if out_s: e.add_field(name='sshx Web Console', value=out_s, inline=False)
    else: e.add_field(name='sshx', value='Not available', inline=False)
    e.add_field(name='Panel Console', value=f'[Open Web Console]({PANEL_URL}/vps/{target["id"]}/console)', inline=False)
    e.set_footer(text='Sessions expire when the server restarts')

    await msg.edit(embed=e)
    try: await ctx.author.send(embed=e)
    except: pass

@bot.hybrid_command(description='Get panel link')
async def panel(ctx):
    e = discord.Embed(title='🌐 Supra Hosting Panel', description=f'Access your control panel here:', color=0x3b82f6)
    e.add_field(name='Panel URL', value=PANEL_URL, inline=False)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(description='Node status')
async def status(ctx):
    r = await panel_api('GET', 'nodes')
    cpu = psutil.cpu_percent(interval=0.5)
    ram = psutil.virtual_memory().percent
    e = discord.Embed(title='📊 Node Status', color=0x3b82f6, timestamp=datetime.utcnow())
    e.add_field(name='Host CPU', value=f'{cpu}%', inline=True)
    e.add_field(name='Host RAM', value=f'{ram}%', inline=True)
    if isinstance(r, list):
        for node in r:
            st = '🟢' if node['status'] == 'online' else '🔴'
            e.add_field(name=f'{st} {node["name"]}',
                        value=f'CPU: {node["cpu"]}% | RAM: {node["ram"]}% | VPS: {node["vps_count"]}',
                        inline=False)
    await ctx.send(embed=e, ephemeral=True)

# ── INVITE COMMANDS ───────────────────────────────────────────────────────────
@bot.hybrid_command(description='Check invite stats')
async def invites(ctx, target: discord.User = None):
    target = target or ctx.author
    inv = invites_table.get(User.id == str(target.id)) or {'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
    valid = inv['joins'] + inv.get('manual', 0) - inv['leaves']
    e = discord.Embed(color=0x3b82f6, timestamp=datetime.utcnow())
    e.description = f'{target.mention} has **{valid}** valid invites.\n\n**Joins:** {inv["joins"] + inv.get("manual",0)}\n**Left:** {inv["leaves"]}\n**Fake:** {inv.get("fakes",0)}'
    await ctx.send(embed=e, ephemeral=True)

# ── ADMIN COMMANDS ────────────────────────────────────────────────────────────
def admin_only():
    async def pred(ctx):
        if ctx.author.id not in ADMIN_IDS:
            await ctx.send(embed=discord.Embed(description='Admin only.', color=0xef4444), ephemeral=True)
            return False
        return True
    return commands.check(pred)

@bot.hybrid_command(description='[Admin] Create a VPS for a user')
@admin_only()
@app_commands.describe(user='Target Discord user', cpu='CPU cores', ram='RAM GB', disk='Disk GB', name='Custom name')
async def admincreate(ctx, user: discord.User, cpu: int = 2, ram: int = 2, disk: int = 20, vps_type: str = 'lxc', name: str = None):
    vps_name = name or f'vps-{user.name.lower()[:10]}-{"".join(secrets.choice(string.ascii_lowercase+string.digits) for _ in range(4))}'
    msg = await ctx.send(embed=blue_embed('🚀 Creating VPS for user...', f'Target: {user.mention}'), ephemeral=True)
    r = await panel_api('POST', 'vps/create', {'name': vps_name, 'type': vps_type, 'cpu': cpu, 'ram': ram, 'disk': disk, 'owner_id': 1})
    if r.get('ok'):
        e = discord.Embed(title='✅ VPS Created', color=0x10b981)
        e.add_field(name='VPS', value=f'`{vps_name}`', inline=True)
        e.add_field(name='Resources', value=f'{cpu}c / {ram}GB / {disk}GB', inline=True)
        e.add_field(name='Type', value=vps_type.upper(), inline=True)
        e.add_field(name='Panel', value=f'[View]({PANEL_URL}/admin/vps)', inline=False)
        await msg.edit(embed=e)
        try: await user.send(embed=discord.Embed(title='🎉 VPS Ready!',
            description=f'An admin has created a VPS for you:\n`{vps_name}`\n\n[View on Panel]({PANEL_URL}/vps/)', color=0x10b981))
        except: pass
        await send_log('Admin: VPS Created for User', f'**Admin:** {ctx.author.mention}\n**User:** {user.mention}\n**VPS:** `{vps_name}`', 0x10b981)
    else:
        await msg.edit(embed=discord.Embed(description=f'Failed: {r.get("error","Unknown")}', color=0xef4444))

@bot.hybrid_command(description='[Admin] List all VPS on the panel')
@admin_only()
async def listall(ctx):
    r = await panel_api('GET', 'vps')
    if not isinstance(r, list):
        await ctx.send(embed=discord.Embed(description='Failed to fetch VPS list.', color=0xef4444), ephemeral=True)
        return
    e = discord.Embed(title=f'All VPS — {len(r)} total', color=0x3b82f6, timestamp=datetime.utcnow())
    for vps in r[:20]:
        st = '🟢' if vps['status'] == 'running' else '🔴'
        e.add_field(name=f'{st} {vps["name"]}',
                    value=f'ID:{vps["id"]} | {vps["cpu"]}c/{vps["ram"]}GB | {vps["status"]}',
                    inline=True)
    if len(r) > 20: e.set_footer(text=f'Showing 20/{len(r)}. View full list on panel.')
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(description='[Admin] List all panel users')
@admin_only()
async def panelusers(ctx):
    r = await panel_api('GET', 'users')
    if not isinstance(r, list):
        await ctx.send(embed=discord.Embed(description='Failed to fetch users.', color=0xef4444), ephemeral=True)
        return
    e = discord.Embed(title=f'Panel Users — {len(r)} total', color=0x3b82f6, timestamp=datetime.utcnow())
    for u in r[:15]:
        role_emoji = '👑' if u['role'] == 'main_admin' else '🔧' if u['role'] == 'admin' else '👤'
        e.add_field(name=f'{role_emoji} {u["username"]}',
                    value=f'ID:{u["id"]} | VPS:{u["vps_count"]} | {u["role"]}',
                    inline=True)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(description='[Admin] Announce to all users')
@admin_only()
async def announce(ctx, *, message: str):
    r = await panel_api('GET', 'users')
    sent = 0
    for u in r:
        if u.get('discord_id'):
            try:
                duser = await bot.fetch_user(int(u['discord_id']))
                e = discord.Embed(title='📢 Supra Hosting Announcement', description=message, color=0xf59e0b, timestamp=datetime.utcnow())
                e.set_footer(text='Supra Hosting Admin Broadcast')
                await duser.send(embed=e)
                sent += 1
            except: pass
    await ctx.send(embed=discord.Embed(description=f'✅ Announcement sent to {sent} users.', color=0x10b981), ephemeral=True)
    await send_log('Admin: Announcement Sent', f'**Admin:** {ctx.author.mention}\n**Message:** {message}\n**Sent to:** {sent} users', 0xf59e0b)

@bot.hybrid_command(description='[Admin] Add manual invites to a user')
@admin_only()
@app_commands.describe(target='Target user', amount='Amount to add (negative to remove)')
async def addinvite(ctx, target: discord.User, amount: int):
    inv = invites_table.get(User.id == str(target.id)) or {'id': str(target.id), 'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
    inv['manual'] = inv.get('manual', 0) + amount
    invites_table.upsert(inv, User.id == str(target.id))
    valid = inv['joins'] + inv['manual'] - inv['leaves']
    await ctx.send(embed=discord.Embed(description=f'Added `{amount}` invites to {target.mention}. Total valid: **{valid}**', color=0x10b981), ephemeral=True)
    await send_log('Admin: Invites Modified', f'**Admin:** {ctx.author.mention}\n**Target:** {target.mention}\n**Amount:** {amount:+}', 0x3b82f6)

@bot.command()
async def sync(ctx):
    if ctx.author.id not in ADMIN_IDS: return
    await bot.tree.sync()
    await ctx.send(embed=discord.Embed(description='✅ Slash commands synced!', color=0x10b981), ephemeral=True)

# ── RUN ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    if not TOKEN:
        print('❌  BOT_TOKEN not set in .env — exiting.')
        exit(1)
    bot.run(TOKEN)
