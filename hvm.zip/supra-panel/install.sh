#!/bin/bash
RED='\033[0;31m';GREEN='\033[0;32m';YELLOW='\033[1;33m';BLUE='\033[0;34m';CYAN='\033[0;36m';WHITE='\033[1;37m';BOLD='\033[1m';DIM='\033[2m';RESET='\033[0m'
VALID_LICENSE="LVM-8F3K2-9XQPL-4Z7MN"
INSTALL_DIR="/opt/supra-panel"
BOT_DIR="/opt/supra-bot"
PANEL_PORT=8888
LOG_FILE="/var/log/supra-installer.log"

print_banner(){
  clear
  echo -e "${BLUE}"
  echo "  ╔═══════════════════════════════════════════════════════════╗"
  echo "  ║                                                           ║"
  echo "  ║        ███████╗██╗   ██╗██████╗ ██████╗  █████╗         ║"
  echo "  ║        ██╔════╝██║   ██║██╔══██╗██╔══██╗██╔══██╗        ║"
  echo "  ║        ███████╗██║   ██║██████╔╝██████╔╝███████║        ║"
  echo "  ║        ╚════██║██║   ██║██╔═══╝ ██╔══██╗██╔══██║        ║"
  echo "  ║        ███████║╚██████╔╝██║     ██║  ██║██║  ██║        ║"
  echo "  ║        ╚══════╝ ╚═════╝ ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝        ║"
  echo "  ║                                                           ║"
  echo -e "  ║         ${WHITE}H O S T I N G${BLUE}  ·  ${CYAN}P A N E L   I N S T A L L E R${BLUE}         ║"
  echo "  ║                                                           ║"
  echo "  ╚═══════════════════════════════════════════════════════════╝"
  echo -e "${RESET}"
}

spinner(){ local pid=$1 msg=$2 spin='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏' i=0
  while kill -0 $pid 2>/dev/null; do i=$(((i+1)%10)); printf "\r  ${CYAN}${spin:$i:1}${RESET}  $msg"; sleep 0.1; done
  printf "\r  ${GREEN}✓${RESET}  $msg\n"; }

license_check(){
  print_banner
  echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "  ${WHITE}  LICENSE VERIFICATION${RESET}"
  echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\n"
  echo -e "  ${DIM}Enter your Supra Hosting license key to activate the panel.${RESET}\n"
  local attempts=0
  while true; do
    attempts=$((attempts+1))
    [ $attempts -gt 3 ] && echo -e "\n  ${RED}✗  Too many failed attempts. Exiting.${RESET}\n" && exit 1
    echo -ne "  ${CYAN}▸${RESET}  License Key: "; read -r key
    key=$(echo "$key" | tr '[:lower:]' '[:upper:]' | xargs)
    if [ "$key" = "$VALID_LICENSE" ]; then
      echo ""; echo -e "  ${GREEN}✓  License validated!${RESET}"; sleep 0.5
      echo ""; echo -e "  ${CYAN}  Access granted — welcome back, ${WHITE}Supra Hosting${RESET}${CYAN}.${RESET}"
      echo -e "  ${DIM}  Good to meet you! We are now directing you to the menu...${RESET}"; sleep 2; break
    else
      echo -e "  ${RED}✗  Invalid license key.${RESET}"
      [ $attempts -lt 3 ] && echo -e "  ${DIM}  Attempts remaining: $((3-attempts))${RESET}\n"
    fi
  done
}

show_menu(){
  while true; do
    print_banner
    echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "  ${WHITE}  MAIN MENU${RESET}"
    echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\n"
    echo -e "    ${CYAN}1${RESET}  ${WHITE}Install Panel${RESET}          ${DIM}Full install (LXC, Docker, panel)${RESET}"
    echo -e "    ${CYAN}2${RESET}  ${WHITE}Install Discord Bot${RESET}     ${DIM}Bot setup with panel integration${RESET}"
    echo -e "    ${CYAN}3${RESET}  ${WHITE}Install Both${RESET}            ${DIM}Panel + Bot complete setup${RESET}"
    echo -e "    ${CYAN}4${RESET}  ${WHITE}Update Panel${RESET}            ${DIM}Update to latest version${RESET}"
    echo -e "    ${CYAN}5${RESET}  ${WHITE}Uninstall${RESET}               ${DIM}Remove Supra Hosting Panel${RESET}"
    echo -e "    ${CYAN}6${RESET}  ${WHITE}Exit${RESET}\n"
    echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -ne "\n  ${CYAN}▸${RESET}  Choose an option [1-6]: "; read -r choice
    case $choice in
      1) install_panel ;;
      2) install_bot ;;
      3) install_panel; install_bot ;;
      4) update_panel ;;
      5) uninstall_panel ;;
      6) echo -e "\n  ${DIM}Goodbye! — Supra Hosting${RESET}\n"; exit 0 ;;
      *) echo -e "\n  ${RED}✗  Invalid option.${RESET}"; sleep 1 ;;
    esac
  done
}

install_panel(){
  print_banner
  echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "  ${WHITE}  PANEL INSTALLATION${RESET}"
  echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\n"
  echo -e "  This will install: LXC/LXD · Docker+Sysbox · Python panel on port ${CYAN}${PANEL_PORT}${RESET}\n"
  echo -ne "  ${CYAN}▸${RESET}  Proceed? [Y/n]: "; read -r c; [[ "$c" =~ ^[Nn] ]] && return

  echo ""; echo -e "  ${WHITE}[1/5] Installing system dependencies...${RESET}"
  (apt-get update -qq && apt-get install -y -qq curl wget git python3 python3-pip python3-venv sqlite3 snapd software-properties-common ca-certificates lsb-release apt-transport-https) >> "$LOG_FILE" 2>&1 &
  spinner $! "Updating packages and installing base tools"

  echo ""; echo -e "  ${WHITE}[2/5] Installing LXC/LXD...${RESET}"
  if ! command -v lxc &>/dev/null; then
    (snap install lxd && /snap/bin/lxd init --auto) >> "$LOG_FILE" 2>&1 & spinner $! "Installing and initializing LXD"
    usermod -aG lxd www-data 2>/dev/null
  else echo -e "  ${GREEN}✓${RESET}  LXC already installed."; fi

  echo ""; echo -e "  ${WHITE}[3/5] Installing Docker + Sysbox (ubuntu-dind support)...${RESET}"
  if ! command -v docker &>/dev/null; then
    (curl -fsSL https://get.docker.com | bash && systemctl enable --now docker) >> "$LOG_FILE" 2>&1 & spinner $! "Installing Docker Engine"
  else echo -e "  ${GREEN}✓${RESET}  Docker already installed."; fi
  cat > /etc/docker/daemon.json '{"runtimes":{"sysbox-runc":{"path":"/usr/bin/sysbox-runc"}},"default-runtime":"runc"}' 2>/dev/null || true
  (wget -q https://downloads.nestybox.com/sysbox/releases/v0.6.4/sysbox-ce_0.6.4-0.linux_amd64.deb -O /tmp/sysbox.deb && dpkg -i /tmp/sysbox.deb || apt-get install -f -y) >> "$LOG_FILE" 2>&1 & spinner $! "Installing Sysbox runtime"

  echo ""; echo -e "  ${WHITE}[4/5] Setting up Python environment...${RESET}"
  mkdir -p "$INSTALL_DIR"
  (python3 -m venv "$INSTALL_DIR/venv" && "$INSTALL_DIR/venv/bin/pip" install --quiet --upgrade pip) >> "$LOG_FILE" 2>&1 & spinner $! "Creating Python virtual environment"
  ("$INSTALL_DIR/venv/bin/pip" install --quiet flask flask-sqlalchemy flask-login flask-socketio flask-wtf paramiko requests psutil python-dotenv eventlet gunicorn werkzeug cryptography aiohttp) >> "$LOG_FILE" 2>&1 & spinner $! "Installing Python dependencies"

  echo ""; echo -e "  ${WHITE}[5/5] Installing panel and configuring service...${RESET}"
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  [ -d "$SCRIPT_DIR/panel" ] && cp -r "$SCRIPT_DIR/panel/"* "$INSTALL_DIR/" >> "$LOG_FILE" 2>&1 & spinner $! "Copying panel files"
  SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  cat > "$INSTALL_DIR/.env" << ENV
SECRET_KEY=$SECRET_KEY
DATABASE_URL=sqlite:///$INSTALL_DIR/supra.db
PANEL_PORT=$PANEL_PORT
PANEL_HOST=0.0.0.0
DEBUG=False
ENV
  cat > /etc/systemd/system/supra-panel.service << SVC
[Unit]
Description=Supra Hosting Panel
After=network.target
[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment=PATH=$INSTALL_DIR/venv/bin
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --worker-class eventlet -w 1 --bind 0.0.0.0:$PANEL_PORT run:app
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC
  (systemctl daemon-reload && systemctl enable supra-panel) >> "$LOG_FILE" 2>&1
  (cd "$INSTALL_DIR" && "$INSTALL_DIR/venv/bin/python" run.py --init-db) >> "$LOG_FILE" 2>&1 & spinner $! "Initializing database"
  systemctl start supra-panel >> "$LOG_FILE" 2>&1 & spinner $! "Starting panel service"

  SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
  echo ""; echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "  ${GREEN}  ✓  INSTALLATION COMPLETE!${RESET}"
  echo -e "  ${DIM}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}\n"
  echo -e "  ${WHITE}Panel URL:${RESET}     ${CYAN}http://${SERVER_IP}:${PANEL_PORT}${RESET}"
  echo -e "  ${WHITE}Login:${RESET}         ${CYAN}admin / admin${RESET}"
  echo -e "  ${WHITE}Install dir:${RESET}   ${CYAN}${INSTALL_DIR}${RESET}"
  echo -e "  ${WHITE}Logs:${RESET}          ${CYAN}journalctl -u supra-panel -f${RESET}"
  echo ""; echo -e "  ${YELLOW}  ⚠  Change the default password after first login!${RESET}\n"
  echo -ne "  Press Enter to return to menu..."; read -r
}

install_bot(){
  print_banner
  echo -e "  ${WHITE}  DISCORD BOT SETUP${RESET}\n"
  echo -ne "  ${CYAN}▸${RESET}  Discord Bot Token: "; read -r BOT_TOKEN
  echo -ne "  ${CYAN}▸${RESET}  Admin Discord User ID: "; read -r ADMIN_ID
  echo -ne "  ${CYAN}▸${RESET}  Admin Log Channel ID: "; read -r ADMIN_LOG
  echo -ne "  ${CYAN}▸${RESET}  Public Log Channel ID: "; read -r PUBLIC_LOG
  echo -ne "  ${CYAN}▸${RESET}  Panel URL (e.g. http://localhost:8888): "; read -r PANEL_URL
  echo -ne "  ${CYAN}▸${RESET}  Panel Admin API Key: "; read -r API_KEY
  mkdir -p "$BOT_DIR"
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  [ -d "$SCRIPT_DIR/bot" ] && cp -r "$SCRIPT_DIR/bot/"* "$BOT_DIR/"
  cat > "$BOT_DIR/.env" << ENV
BOT_TOKEN=$BOT_TOKEN
ADMIN_IDS=$ADMIN_ID
ADMIN_LOG_CHANNEL=$ADMIN_LOG
PUBLIC_LOG_CHANNEL=$PUBLIC_LOG
PANEL_URL=$PANEL_URL
PANEL_API_KEY=$API_KEY
PREFIX=!
ENV
  (python3 -m venv "$BOT_DIR/venv" && "$BOT_DIR/venv/bin/pip" install --quiet discord.py python-dotenv aiohttp psutil tinydb requests) >> "$LOG_FILE" 2>&1 & spinner $! "Installing bot dependencies"
  cat > /etc/systemd/system/supra-bot.service << SVC
[Unit]
Description=Supra Hosting Discord Bot
After=network.target
[Service]
Type=simple
User=root
WorkingDirectory=$BOT_DIR
Environment=PATH=$BOT_DIR/venv/bin
ExecStart=$BOT_DIR/venv/bin/python bot.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
SVC
  systemctl daemon-reload && systemctl enable supra-bot && systemctl start supra-bot >> "$LOG_FILE" 2>&1
  echo -e "\n  ${GREEN}✓  Discord bot installed and running!${RESET}"
  echo -e "  ${DIM}  Check: systemctl status supra-bot${RESET}\n"
  echo -ne "  Press Enter to return to menu..."; read -r
}

update_panel(){
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  [ -d "$SCRIPT_DIR/panel" ] && cp -r "$SCRIPT_DIR/panel/"* "$INSTALL_DIR/" 2>/dev/null
  systemctl restart supra-panel
  echo -e "\n  ${GREEN}✓  Panel updated and restarted.${RESET}\n"
  echo -ne "  Press Enter..."; read -r
}

uninstall_panel(){
  echo -ne "\n  ${RED}⚠  Uninstall everything? Type 'yes' to confirm: ${RESET}"; read -r c
  [ "$c" != "yes" ] && return
  systemctl stop supra-panel supra-bot 2>/dev/null; systemctl disable supra-panel supra-bot 2>/dev/null
  rm -f /etc/systemd/system/supra-panel.service /etc/systemd/system/supra-bot.service
  rm -rf /opt/supra-panel /opt/supra-bot; systemctl daemon-reload
  echo -e "\n  ${GREEN}✓  Uninstalled successfully.${RESET}\n"; echo -ne "  Press Enter..."; read -r
}

touch "$LOG_FILE"
[ $EUID -ne 0 ] && echo -e "\n  ${RED}✗  Run as root: sudo bash install.sh${RESET}\n" && exit 1
license_check
show_menu
