from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_socketio import SocketIO
import os, secrets

from .models import db, User, Settings, Node, OSIcon

login_manager = LoginManager()
socketio = SocketIO()

def create_app():
    app = Flask(__name__, template_folder='templates', static_folder='static')
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///supra.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024
    app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'uploads')

    for sub in ('settings','avatars','wallpapers','os_icons','backups'):
        os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], sub), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = ''
    socketio.init_app(app, cors_allowed_origins='*', async_mode='eventlet')

    @login_manager.user_loader
    def load_user(uid): return User.query.get(int(uid))

    from .routes.auth  import auth_bp
    from .routes.main  import main_bp
    from .routes.vps   import vps_bp
    from .routes.nodes import nodes_bp
    from .routes.admin import admin_bp
    from .routes.api   import api_bp
    from .routes.ws    import register_ws

    app.register_blueprint(auth_bp,  url_prefix='/auth')
    app.register_blueprint(main_bp,  url_prefix='/')
    app.register_blueprint(vps_bp,   url_prefix='/vps')
    app.register_blueprint(nodes_bp, url_prefix='/nodes')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(api_bp,   url_prefix='/api')
    register_ws(socketio)

    with app.app_context():
        db.create_all()
        _seed()
    return app

def _seed():
    if not User.query.filter_by(role='main_admin').first():
        a = User(username='admin', email='admin@supra.local', role='main_admin', port_quota=100, first_login=True)
        a.set_password('admin'); a.generate_api_key()
        db.session.add(a); db.session.commit()

    if not Node.query.first():
        db.session.add(Node(name='Local', location='Local', host='localhost', is_local=True, max_vps=50, status='online'))
        db.session.commit()

    defaults = {
        'site_name':'Supra Hosting','site_description':'High-Performance VPS Management',
        'footer_text':'Powered by Supra Hosting © 2026 | Version 1.0','timezone':'UTC',
        'enable_registration':'true','enable_discord_auth':'false',
        'discord_client_id':'','discord_client_secret':'','discord_redirect_uri':'',
        'discord_allow_auto_register':'true','discord_button_text':'Sign in with Discord',
        'cpu_threshold':'90','ram_threshold':'90','maintenance_mode':'false',
        'maintenance_message':'Site is under maintenance. Please check back later.',
        'wallpaper_type':'color','wallpaper_value':'gradient-1',
        'header_icon_url':'','favicon_url':'','panel_bg_opacity':'0.85',
    }
    for k,v in defaults.items():
        if not Settings.query.filter_by(key=k).first():
            db.session.add(Settings(key=k, value=v))

    os_list = [
        ('Ubuntu 20.04 LTS','ubuntu:20.04'),('Ubuntu 22.04 LTS','ubuntu:22.04'),
        ('Ubuntu 24.04 LTS','ubuntu:24.04'),('Debian 10 (Buster)','images:debian/10'),
        ('Debian 11 (Bullseye)','images:debian/11'),('Debian 12 (Bookworm)','images:debian/12'),
        ('Debian 13 (Trixie)','images:debian/13'),('Alpine Linux 3.19','images:alpine/3.19'),
        ('CentOS 9 Stream','images:centos/9-Stream'),('Fedora 39','images:fedora/39'),
    ]
    for name,key in os_list:
        if not OSIcon.query.filter_by(template_key=key).first():
            db.session.add(OSIcon(name=name, template_key=key))
    db.session.commit()
