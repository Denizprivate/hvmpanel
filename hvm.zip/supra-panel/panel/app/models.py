from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import secrets

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(80), unique=True, nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=True)
    avatar_url    = db.Column(db.String(500), default='')
    role          = db.Column(db.String(20), default='user')
    discord_id    = db.Column(db.String(50), unique=True, nullable=True)
    discord_username = db.Column(db.String(100), nullable=True)
    api_key       = db.Column(db.String(64), unique=True)
    port_quota    = db.Column(db.Integer, default=5)
    is_suspended  = db.Column(db.Boolean, default=False)
    first_login   = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    last_login    = db.Column(db.DateTime, nullable=True)
    last_active   = db.Column(db.DateTime, nullable=True)
    vps_list      = db.relationship('VPS', backref='owner', lazy=True, foreign_keys='VPS.owner_id')
    notifications = db.relationship('Notification', backref='user', lazy=True)
    activity_logs = db.relationship('ActivityLog', backref='user', lazy=True)

    def set_password(self, p): self.password_hash = generate_password_hash(p)
    def check_password(self, p): return self.password_hash and check_password_hash(self.password_hash, p)
    def generate_api_key(self): self.api_key = secrets.token_urlsafe(48)
    @property
    def is_admin(self): return self.role in ('admin', 'main_admin')
    @property
    def is_main_admin(self): return self.role == 'main_admin'

class Node(db.Model):
    __tablename__ = 'nodes'
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    location   = db.Column(db.String(100), default='Local')
    host       = db.Column(db.String(200), default='localhost')
    ssh_port   = db.Column(db.Integer, default=22)
    ssh_user   = db.Column(db.String(50), default='root')
    is_local   = db.Column(db.Boolean, default=True)
    max_vps    = db.Column(db.Integer, default=50)
    status     = db.Column(db.String(20), default='online')
    cpu_usage  = db.Column(db.Float, default=0.0)
    ram_usage  = db.Column(db.Float, default=0.0)
    disk_usage = db.Column(db.Float, default=0.0)
    last_seen  = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    vps_list   = db.relationship('VPS', backref='node', lazy=True)
    @property
    def vps_count(self): return len(self.vps_list)

class VPS(db.Model):
    __tablename__ = 'vps'
    id           = db.Column(db.Integer, primary_key=True)
    name         = db.Column(db.String(100), nullable=False)
    hostname     = db.Column(db.String(100), nullable=False)
    owner_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    node_id      = db.Column(db.Integer, db.ForeignKey('nodes.id'), nullable=False)
    vps_type     = db.Column(db.String(20), default='lxc')
    os_template  = db.Column(db.String(100), default='ubuntu:22.04')
    status       = db.Column(db.String(20), default='stopped')
    cpu_cores    = db.Column(db.Integer, default=2)
    ram_gb       = db.Column(db.Integer, default=2)
    disk_gb      = db.Column(db.Integer, default=20)
    ip_address   = db.Column(db.String(50), nullable=True)
    ip_alias     = db.Column(db.String(200), nullable=True)
    cpu_usage    = db.Column(db.Float, default=0.0)
    ram_usage    = db.Column(db.Float, default=0.0)
    expiry_date  = db.Column(db.DateTime, nullable=True)
    auto_suspend = db.Column(db.Boolean, default=False)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at   = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    port_forwards= db.relationship('PortForward', backref='vps', lazy=True)

class PortForward(db.Model):
    __tablename__ = 'port_forwards'
    id             = db.Column(db.Integer, primary_key=True)
    vps_id         = db.Column(db.Integer, db.ForeignKey('vps.id'), nullable=False)
    host_port      = db.Column(db.Integer, nullable=False)
    container_port = db.Column(db.Integer, nullable=False)
    protocol       = db.Column(db.String(10), default='tcp')
    description    = db.Column(db.String(200), nullable=True)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    __tablename__ = 'notifications'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title      = db.Column(db.String(200), nullable=False)
    message    = db.Column(db.Text, nullable=False)
    type       = db.Column(db.String(30), default='info')
    is_read    = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ActivityLog(db.Model):
    __tablename__ = 'activity_logs'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    action     = db.Column(db.String(100), nullable=False)
    resource   = db.Column(db.String(200), nullable=True)
    details    = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    id         = db.Column(db.Integer, primary_key=True)
    level      = db.Column(db.String(20), default='info')
    source     = db.Column(db.String(100), nullable=True)
    message    = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Settings(db.Model):
    __tablename__ = 'settings'
    id         = db.Column(db.Integer, primary_key=True)
    key        = db.Column(db.String(100), unique=True, nullable=False)
    value      = db.Column(db.Text, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @staticmethod
    def get(key, default=None):
        s = Settings.query.filter_by(key=key).first()
        return s.value if s else default

    @staticmethod
    def set(key, value):
        s = Settings.query.filter_by(key=key).first()
        if s: s.value = value
        else: s = Settings(key=key, value=value); db.session.add(s)
        db.session.commit()

class OSIcon(db.Model):
    __tablename__ = 'os_icons'
    id           = db.Column(db.Integer, primary_key=True)
    name         = db.Column(db.String(100), nullable=False)
    template_key = db.Column(db.String(100), unique=True, nullable=False)
    icon_url     = db.Column(db.String(500), nullable=True)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)

class Backup(db.Model):
    __tablename__ = 'backups'
    id         = db.Column(db.Integer, primary_key=True)
    filename   = db.Column(db.String(200), nullable=False)
    size_bytes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
