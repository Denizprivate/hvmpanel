from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, current_app, send_file
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from functools import wraps
import os, secrets, shutil, psutil, subprocess, time, platform

from ..models import db, User, VPS, Node, Notification, ActivityLog, SystemLog, Settings, OSIcon, Backup, PortForward

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated

def _gs():
    return {'site_name':Settings.get('site_name','Supra Hosting'),'footer_text':Settings.get('footer_text',''),
            'wallpaper_type':Settings.get('wallpaper_type','color'),'wallpaper_value':Settings.get('wallpaper_value','gradient-1'),
            'header_icon_url':Settings.get('header_icon_url',''),'bg_opacity':Settings.get('panel_bg_opacity','0.85')}

def run_cmd(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except: return '', 'Timeout', 1

@admin_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    total_users=User.query.count(); total_vps=VPS.query.count()
    running_vps=VPS.query.filter_by(status='running').count(); suspended_vps=VPS.query.filter_by(status='suspended').count()
    port_usage=PortForward.query.count(); port_max=sum(u.port_quota for u in User.query.all())
    cpu=psutil.cpu_percent(interval=0.5); ram=psutil.virtual_memory(); disk=psutil.disk_usage('/')
    boot=datetime.fromtimestamp(psutil.boot_time()); uptime=datetime.now()-boot
    nodes=Node.query.all(); logs=SystemLog.query.order_by(SystemLog.created_at.desc()).limit(50).all()
    return render_template('admin/dashboard.html', total_users=total_users, total_vps=total_vps,
        running_vps=running_vps, suspended_vps=suspended_vps, port_usage=port_usage, port_max=port_max,
        cpu=cpu, ram=ram, disk=disk, uptime=uptime, nodes=nodes, logs=logs, **_gs())

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    search=request.args.get('q',''); q=User.query
    if search: q=q.filter((User.username.ilike(f'%{search}%'))|(User.email.ilike(f'%{search}%')))
    users=q.order_by(User.created_at.desc()).all()
    admins=sum(1 for u in users if u.is_admin); total_vps=VPS.query.count()
    expiring=VPS.query.filter(VPS.expiry_date<=datetime.utcnow()+timedelta(days=7)).count()
    return render_template('admin/users.html', users=users, admins=admins, total_vps=total_vps, expiring=expiring, **_gs())

@admin_bp.route('/users/create', methods=['POST'])
@login_required
@admin_required
def create_user():
    username=request.form.get('username','').strip(); email=request.form.get('email','').strip().lower()
    password=request.form.get('password',''); role=request.form.get('role','user'); quota=request.form.get('port_quota',5,type=int)
    if User.query.filter_by(username=username).first(): flash('Username exists.','error'); return redirect(url_for('admin.users'))
    u=User(username=username, email=email, role=role, port_quota=quota); u.set_password(password); u.generate_api_key()
    db.session.add(u); db.session.commit(); flash(f'User {username} created.','success'); return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:uid>/edit', methods=['POST'])
@login_required
@admin_required
def edit_user(uid):
    user=User.query.get_or_404(uid); data=request.json
    if 'role' in data: user.role=data['role']
    if 'port_quota' in data: user.port_quota=int(data['port_quota'])
    if 'is_suspended' in data: user.is_suspended=data['is_suspended']
    db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/users/<int:uid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(uid):
    user=User.query.get_or_404(uid)
    if user.id==current_user.id: return jsonify({'error':'Cannot delete yourself'}), 400
    for vps in user.vps_list: db.session.delete(vps)
    db.session.delete(user); db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/vps')
@login_required
@admin_required
def all_vps():
    search=request.args.get('q',''); node_id=request.args.get('node',type=int); status=request.args.get('status','')
    q=VPS.query
    if search: q=q.filter((VPS.name.ilike(f'%{search}%'))|(VPS.hostname.ilike(f'%{search}%')))
    if node_id: q=q.filter_by(node_id=node_id)
    if status: q=q.filter_by(status=status)
    vps_list=q.order_by(VPS.created_at.desc()).all(); nodes=Node.query.all()
    return render_template('admin/vps.html', vps_list=vps_list, nodes=nodes, **_gs())

@admin_bp.route('/vps/create', methods=['GET','POST'])
@login_required
@admin_required
def create_vps():
    if request.method=='POST':
        data=request.form.to_dict()
        owner=User.query.get(int(data.get('owner_id',1))); node=Node.query.get(int(data.get('node_id',1)))
        if not owner or not node: flash('Invalid owner or node.','error'); return redirect(url_for('admin.create_vps'))
        name=data.get('name','') or f'vps-{owner.username[:8]}-{"".join(secrets.choice("abcdefghijklmnop0123456789") for _ in range(4))}'
        vps=VPS(name=name, hostname=name.lower().replace(' ','-'), owner_id=owner.id, node_id=node.id,
                vps_type=data.get('vps_type','lxc'), os_template=data.get('os_template','ubuntu:22.04'),
                cpu_cores=int(data.get('cpu_cores',2)), ram_gb=int(data.get('ram_gb',2)), disk_gb=int(data.get('disk_gb',20)),
                ip_address=data.get('ip_address') or None, ip_alias=data.get('ip_alias') or None,
                status='creating', auto_suspend=bool(data.get('auto_suspend')))
        if data.get('expiry_days') and int(data['expiry_days'])>0:
            vps.expiry_date=datetime.utcnow()+timedelta(days=int(data['expiry_days']))
        db.session.add(vps); db.session.commit(); flash(f'VPS "{vps.name}" queued for creation.','success')
        return redirect(url_for('admin.all_vps'))
    users=User.query.all(); nodes=Node.query.all(); os_icons=OSIcon.query.all()
    return render_template('admin/create_vps.html', users=users, nodes=nodes, os_icons=os_icons, **_gs())

@admin_bp.route('/vps/<int:vps_id>/action', methods=['POST'])
@login_required
@admin_required
def vps_action(vps_id):
    vps=VPS.query.get_or_404(vps_id); action=request.json.get('action')
    cmds={'start':f'lxc start {vps.hostname}','stop':f'lxc stop {vps.hostname} --force','restart':f'lxc restart {vps.hostname}','delete':f'lxc delete {vps.hostname} --force'}
    if action=='suspend': run_cmd(f'lxc stop {vps.hostname} --force'); vps.status='suspended'; db.session.commit(); return jsonify({'ok':True})
    cmd=cmds.get(action)
    if cmd: run_cmd(cmd)
    if action=='start': vps.status='running'
    elif action=='stop': vps.status='stopped'
    elif action=='restart': vps.status='running'
    elif action=='delete': db.session.delete(vps); db.session.commit(); return jsonify({'ok':True,'deleted':True})
    db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/expiring')
@login_required
@admin_required
def expiring():
    days=request.args.get('days',7,type=int); cutoff=datetime.utcnow()+timedelta(days=days)
    expired=VPS.query.filter(VPS.expiry_date<datetime.utcnow()).all()
    expiring_soon=VPS.query.filter(VPS.expiry_date>=datetime.utcnow(), VPS.expiry_date<=cutoff).all()
    return render_template('admin/expiring.html', expired=expired, expiring_soon=expiring_soon, days=days, **_gs())

@admin_bp.route('/expiring/bulk', methods=['POST'])
@login_required
@admin_required
def expiring_bulk():
    action=request.json.get('action'); ids=request.json.get('ids',[])
    for vid in ids:
        vps=VPS.query.get(vid)
        if not vps: continue
        if action=='delete': run_cmd(f'lxc delete {vps.hostname} --force'); db.session.delete(vps)
        elif action=='suspend': run_cmd(f'lxc stop {vps.hostname} --force'); vps.status='suspended'
        elif action=='renew': vps.expiry_date=(vps.expiry_date or datetime.utcnow())+timedelta(days=30)
    db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/nodes')
@login_required
@admin_required
def nodes():
    nodes=Node.query.all(); return render_template('admin/nodes.html', nodes=nodes, **_gs())

@admin_bp.route('/nodes/create', methods=['POST'])
@login_required
@admin_required
def create_node():
    node=Node(name=request.form.get('name',''), location=request.form.get('location','Local'),
              host=request.form.get('host','localhost'), ssh_port=request.form.get('ssh_port',22,type=int),
              ssh_user=request.form.get('ssh_user','root'), is_local=bool(request.form.get('is_local')),
              max_vps=request.form.get('max_vps',50,type=int))
    db.session.add(node); db.session.commit(); flash('Node added.','success'); return redirect(url_for('admin.nodes'))

@admin_bp.route('/nodes/<int:nid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_node(nid):
    node=Node.query.get_or_404(nid)
    if node.vps_list: return jsonify({'error':'Node has active VPS'}), 400
    db.session.delete(node); db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/os-icons')
@login_required
@admin_required
def os_icons():
    icons=OSIcon.query.all(); return render_template('admin/os_icons.html', icons=icons, **_gs())

@admin_bp.route('/os-icons/<int:icon_id>/upload', methods=['POST'])
@login_required
@admin_required
def upload_os_icon(icon_id):
    icon=OSIcon.query.get_or_404(icon_id)
    if 'icon' in request.files:
        f=request.files['icon']
        if f and f.filename:
            ext=f.filename.rsplit('.',1)[-1].lower(); fname=f'os_{icon_id}_{secrets.token_hex(4)}.{ext}'
            path=os.path.join(current_app.config['UPLOAD_FOLDER'],'os_icons',fname); f.save(path)
            icon.icon_url=f'/static/uploads/os_icons/{fname}'; db.session.commit()
    return jsonify({'ok':True,'url':icon.icon_url})

@admin_bp.route('/settings', methods=['GET','POST'])
@login_required
@admin_required
def settings():
    if request.method=='POST':
        for f in ['site_name','site_description','footer_text','timezone','enable_registration',
                  'cpu_threshold','ram_threshold','maintenance_mode','maintenance_message',
                  'enable_discord_auth','discord_client_id','discord_client_secret','discord_redirect_uri',
                  'discord_allow_auto_register','discord_button_text','wallpaper_type','wallpaper_value',
                  'panel_bg_opacity','header_icon_url','favicon_url']:
            val=request.form.get(f)
            if val is not None: Settings.set(f, val)
        for key in ('header_icon','favicon'):
            if key in request.files:
                file=request.files[key]
                if file and file.filename:
                    ext=file.filename.rsplit('.',1)[-1].lower(); fname=f'{key}_{int(time.time())}.{ext}'
                    path=os.path.join(current_app.config['UPLOAD_FOLDER'],'settings',fname); file.save(path)
                    Settings.set(f'{key}_url', f'/static/uploads/settings/{fname}')
        if 'wallpaper_file' in request.files:
            wf=request.files['wallpaper_file']
            if wf and wf.filename:
                ext=wf.filename.rsplit('.',1)[-1].lower(); fname=f'wallpaper_{int(time.time())}.{ext}'
                path=os.path.join(current_app.config['UPLOAD_FOLDER'],'wallpapers',fname); wf.save(path)
                Settings.set('wallpaper_type','video' if ext in ('mp4','webm') else 'image')
                Settings.set('wallpaper_value',f'/static/uploads/wallpapers/{fname}')
        db.session.add(Notification(user_id=current_user.id, title='Settings Updated', message='Panel settings updated.', type='success'))
        db.session.commit(); flash('Settings saved.','success'); return redirect(url_for('admin.settings'))
    all_settings={s.key:s.value for s in Settings.query.all()}
    GRADIENTS=[
        {'id':'gradient-1','name':'Deep Space','preview':'linear-gradient(135deg,#0a0a1a,#1a1a3e,#0d2137)'},
        {'id':'gradient-2','name':'Ocean Blue','preview':'linear-gradient(135deg,#0f0c29,#302b63,#24243e)'},
        {'id':'gradient-3','name':'Midnight','preview':'linear-gradient(135deg,#000428,#004e92)'},
        {'id':'gradient-4','name':'Aurora','preview':'linear-gradient(135deg,#0d1117,#0d3a5c,#0a2340)'},
        {'id':'gradient-5','name':'Nebula','preview':'linear-gradient(135deg,#09090f,#1a0533,#0a1a40)'},
        {'id':'gradient-6','name':'Storm','preview':'linear-gradient(135deg,#111827,#1e3a5f,#0f2944)'},
        {'id':'gradient-7','name':'Abyss','preview':'linear-gradient(135deg,#000000,#0a0a2a,#000a1a)'},
        {'id':'gradient-8','name':'Frost','preview':'linear-gradient(135deg,#0c1445,#1a2980,#26d0ce)'},
        {'id':'gradient-9','name':'Plasma','preview':'linear-gradient(135deg,#0f0c29,#2d0f5a,#1a0c3a)'},
        {'id':'gradient-10','name':'Horizon','preview':'linear-gradient(135deg,#1a1a2e,#16213e,#0f3460)'},
    ]
    wp_folder=os.path.join(current_app.config['UPLOAD_FOLDER'],'wallpapers'); uploaded_wps=[]
    if os.path.exists(wp_folder):
        for f in os.listdir(wp_folder): uploaded_wps.append({'filename':f,'url':f'/static/uploads/wallpapers/{f}'})
    return render_template('admin/settings.html', all_settings=all_settings, gradients=GRADIENTS, uploaded_wps=uploaded_wps, **_gs())

@admin_bp.route('/system-info')
@login_required
@admin_required
def system_info():
    cpu_pct=psutil.cpu_percent(interval=1); cpu_count=psutil.cpu_count(); mem=psutil.virtual_memory()
    disk=psutil.disk_usage('/'); disks=[]
    for part in psutil.disk_partitions():
        try: usage=psutil.disk_usage(part.mountpoint); disks.append({'mount':part.mountpoint,'usage':usage})
        except: pass
    boot_time=datetime.fromtimestamp(psutil.boot_time()); uptime=datetime.now()-boot_time
    hostname=platform.node(); system=platform.system(); release=platform.release(); machine=platform.machine()
    cpu_model=''
    try:
        r=subprocess.run('cat /proc/cpuinfo | grep "model name" | head -1',shell=True,capture_output=True,text=True)
        cpu_model=r.stdout.split(':')[-1].strip()
    except: pass
    return render_template('admin/system_info.html', cpu_pct=cpu_pct, cpu_count=cpu_count, cpu_model=cpu_model,
        mem=mem, disk=disk, disks=disks, boot_time=boot_time, uptime=uptime,
        hostname=hostname, system=system, release=release, machine=machine, **_gs())

@admin_bp.route('/logs')
@login_required
@admin_required
def logs():
    logs=SystemLog.query.order_by(SystemLog.created_at.desc()).limit(500).all()
    return render_template('admin/logs.html', logs=logs, **_gs())

@admin_bp.route('/backups')
@login_required
@admin_required
def backups():
    bk_list=Backup.query.order_by(Backup.created_at.desc()).all()
    return render_template('admin/backups.html', backups=bk_list, **_gs())

@admin_bp.route('/backups/create', methods=['POST'])
@login_required
@admin_required
def create_backup():
    fname=f'supra_backup_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}.db'
    bk_dir=os.path.join(current_app.config['UPLOAD_FOLDER'],'backups'); os.makedirs(bk_dir, exist_ok=True)
    # Find the DB file
    db_paths=['supra.db','instance/supra.db','/opt/supra-panel/supra.db']
    src=next((p for p in db_paths if os.path.exists(p)), None)
    if not src: return jsonify({'error':'Database file not found'}), 500
    dst=os.path.join(bk_dir, fname)
    try:
        shutil.copy2(src, dst); size=os.path.getsize(dst)
        bk=Backup(filename=fname, size_bytes=size); db.session.add(bk); db.session.commit()
        return jsonify({'ok':True,'filename':fname})
    except Exception as e: return jsonify({'error':str(e)}), 500

@admin_bp.route('/backups/<int:bid>/download')
@login_required
@admin_required
def download_backup(bid):
    bk=Backup.query.get_or_404(bid)
    path=os.path.join(current_app.config['UPLOAD_FOLDER'],'backups',bk.filename)
    return send_file(path, as_attachment=True)

@admin_bp.route('/backups/<int:bid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_backup(bid):
    bk=Backup.query.get_or_404(bid)
    path=os.path.join(current_app.config['UPLOAD_FOLDER'],'backups',bk.filename)
    if os.path.exists(path): os.remove(path)
    db.session.delete(bk); db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/maintenance')
@login_required
@admin_required
def maintenance():
    cpu=psutil.cpu_percent(interval=0.5); mem=psutil.virtual_memory(); disk=psutil.disk_usage('/')
    hostname=platform.node()
    try: lxc_ver=subprocess.run('lxc version',shell=True,capture_output=True,text=True).stdout.strip()
    except: lxc_ver='N/A'
    return render_template('admin/maintenance.html', cpu=cpu, mem=mem, disk=disk, hostname=hostname, lxc_ver=lxc_ver, **_gs())

@admin_bp.route('/maintenance/emergency', methods=['POST'])
@login_required
@admin_required
def emergency_action():
    action=request.json.get('action')
    if action=='stop_all': subprocess.run('lxc list --format csv -c n | xargs -I{} lxc stop {} --force 2>/dev/null', shell=True); VPS.query.update({'status':'stopped'}); db.session.commit()
    elif action=='reboot_all': subprocess.run('lxc list --format csv -c n | xargs -I{} lxc restart {} 2>/dev/null', shell=True)
    elif action=='clear_suspensions': VPS.query.filter_by(status='suspended').update({'status':'stopped'}); db.session.commit()
    return jsonify({'ok':True})

@admin_bp.route('/emergency-stop', methods=['POST'])
@login_required
@admin_required
def emergency_stop():
    subprocess.run('lxc list --format csv -c n | xargs -I{} lxc stop {} --force 2>/dev/null', shell=True)
    VPS.query.update({'status':'stopped'}); db.session.commit(); return jsonify({'ok':True})

@admin_bp.route('/api-management')
@login_required
@admin_required
def api_management():
    admin_key=Settings.get('admin_api_key','')
    if not admin_key: admin_key=secrets.token_urlsafe(48); Settings.set('admin_api_key', admin_key)
    return render_template('admin/api_management.html', admin_key=admin_key, **_gs())
