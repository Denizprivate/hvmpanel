from flask import Blueprint, jsonify, request
from functools import wraps
from ..models import db, User, VPS, Node, Settings, Notification
import subprocess

api_bp = Blueprint('api', __name__)

def api_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        key = request.headers.get('X-API-Key') or request.args.get('api_key')
        if not key: return jsonify({'error':'No API key'}), 401
        admin_key = Settings.get('admin_api_key','')
        if key == admin_key: return f(*args, is_admin=True, api_user=None, **kwargs)
        user = User.query.filter_by(api_key=key).first()
        if not user: return jsonify({'error':'Invalid API key'}), 401
        return f(*args, is_admin=user.is_admin, api_user=user, **kwargs)
    return decorated

def run_cmd(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
    return r.stdout.strip()

@api_bp.route('/v1/status')
def status():
    return jsonify({'status':'ok','version':'1.0.0','panel':Settings.get('site_name','Supra Hosting')})

@api_bp.route('/v1/vps')
@api_auth
def api_list_vps(is_admin, api_user):
    vps_list = VPS.query.all() if (is_admin and not api_user) else (VPS.query.filter_by(owner_id=api_user.id).all() if api_user else [])
    return jsonify([{'id':v.id,'name':v.name,'hostname':v.hostname,'status':v.status,'type':v.vps_type,
                     'cpu':v.cpu_cores,'ram':v.ram_gb,'disk':v.disk_gb,'ip':v.ip_address,
                     'owner_id':v.owner_id,'created_at':v.created_at.isoformat()} for v in vps_list])

@api_bp.route('/v1/vps/create', methods=['POST'])
@api_auth
def api_create_vps(is_admin, api_user):
    if not is_admin: return jsonify({'error':'Admin only'}), 403
    data = request.json or {}
    owner = User.query.get(data.get('owner_id',1))
    node  = Node.query.get(data.get('node_id',1))
    if not owner: return jsonify({'error':'Owner not found'}), 404
    if not node: return jsonify({'error':'Node not found'}), 404
    vps = VPS(name=data.get('name','api-vps'), hostname=data.get('name','api-vps').lower().replace(' ','-'),
              owner_id=owner.id, node_id=node.id, vps_type=data.get('type','lxc'),
              os_template=data.get('os','ubuntu:22.04'), cpu_cores=data.get('cpu',2),
              ram_gb=data.get('ram',2), disk_gb=data.get('disk',20), status='creating')
    db.session.add(vps); db.session.commit()
    db.session.add(Notification(user_id=owner.id, title='VPS Created via API', message=f'VPS "{vps.name}" created for you.', type='success'))
    db.session.commit()
    return jsonify({'ok':True,'vps_id':vps.id,'name':vps.name})

@api_bp.route('/v1/vps/<int:vps_id>/action', methods=['POST'])
@api_auth
def api_vps_action(vps_id, is_admin, api_user):
    vps = VPS.query.get_or_404(vps_id)
    if not is_admin and (not api_user or vps.owner_id != api_user.id): return jsonify({'error':'Unauthorized'}), 403
    action = request.json.get('action')
    cmds = {'start':f'lxc start {vps.hostname}','stop':f'lxc stop {vps.hostname} --force','restart':f'lxc restart {vps.hostname}','delete':f'lxc delete {vps.hostname} --force'}
    if action not in cmds: return jsonify({'error':'Unknown action'}), 400
    subprocess.run(cmds[action], shell=True)
    if action == 'start': vps.status = 'running'
    elif action == 'stop': vps.status = 'stopped'
    elif action == 'restart': vps.status = 'running'
    elif action == 'delete':
        db.session.delete(vps); db.session.commit(); return jsonify({'ok':True,'deleted':True})
    db.session.commit()
    return jsonify({'ok':True,'status':vps.status})

@api_bp.route('/v1/nodes')
@api_auth
def api_nodes(is_admin, api_user):
    nodes = Node.query.all()
    return jsonify([{'id':n.id,'name':n.name,'status':n.status,'cpu':n.cpu_usage,'ram':n.ram_usage,'vps_count':n.vps_count} for n in nodes])

@api_bp.route('/v1/users')
@api_auth
def api_users(is_admin, api_user):
    if not is_admin: return jsonify({'error':'Admin only'}), 403
    return jsonify([{'id':u.id,'username':u.username,'email':u.email,'role':u.role,'discord_id':u.discord_id,'vps_count':len(u.vps_list)} for u in User.query.all()])
