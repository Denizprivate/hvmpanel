from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
import requests as req_lib

from ..models import db, User, Settings, Notification, ActivityLog

auth_bp = Blueprint('auth', __name__)

def _log(user, action, details=None):
    db.session.add(ActivityLog(user_id=user.id, action=action, details=details, ip_address=request.remote_addr))
    db.session.commit()

@auth_bp.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        remember = bool(request.form.get('remember'))
        user = User.query.filter((User.username==username)|(User.email==username)).first()
        if user and user.check_password(password):
            if user.is_suspended: flash('Account suspended.','error'); return render_template('auth/login.html',site_name=Settings.get('site_name','Supra Hosting'),discord_enabled=False,discord_client_id='')
            user.last_login = user.last_active = datetime.utcnow(); db.session.commit()
            login_user(user, remember=remember)
            db.session.add(Notification(user_id=user.id, title='New Login', message=f'New login from {request.remote_addr}', type='info'))
            _log(user, 'login', f'IP: {request.remote_addr}')
            return redirect(url_for('main.dashboard'))
        flash('Invalid username or password.','error')
    site_name = Settings.get('site_name','Supra Hosting')
    discord_enabled = Settings.get('enable_discord_auth','false') == 'true'
    discord_client_id = Settings.get('discord_client_id','')
    return render_template('auth/login.html', site_name=site_name, discord_enabled=discord_enabled, discord_client_id=discord_client_id)

@auth_bp.route('/register', methods=['GET','POST'])
def register():
    if current_user.is_authenticated: return redirect(url_for('main.dashboard'))
    if Settings.get('enable_registration','true') != 'true':
        flash('Registration is currently disabled.','error'); return redirect(url_for('auth.login'))
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        email    = request.form.get('email','').strip().lower()
        password = request.form.get('password','')
        confirm  = request.form.get('confirm_password','')
        if not username or not email or not password: flash('All fields required.','error')
        elif password != confirm: flash('Passwords do not match.','error')
        elif len(password) < 6: flash('Password must be at least 6 characters.','error')
        elif User.query.filter_by(username=username).first(): flash('Username taken.','error')
        elif User.query.filter_by(email=email).first(): flash('Email already registered.','error')
        else:
            u = User(username=username, email=email); u.set_password(password); u.generate_api_key()
            db.session.add(u); db.session.commit(); login_user(u)
            return redirect(url_for('main.dashboard'))
    return render_template('auth/register.html', site_name=Settings.get('site_name','Supra Hosting'))

@auth_bp.route('/discord')
def discord_login():
    cid = Settings.get('discord_client_id',''); ruri = Settings.get('discord_redirect_uri','')
    if not cid: flash('Discord auth not configured.','error'); return redirect(url_for('auth.login'))
    return redirect(f"https://discord.com/api/oauth2/authorize?client_id={cid}&redirect_uri={ruri}&response_type=code&scope=identify+email")

@auth_bp.route('/discord/callback')
def discord_callback():
    code = request.args.get('code')
    if not code: flash('Discord auth failed.','error'); return redirect(url_for('auth.login'))
    cid = Settings.get('discord_client_id',''); sec = Settings.get('discord_client_secret',''); ruri = Settings.get('discord_redirect_uri','')
    r = req_lib.post('https://discord.com/api/oauth2/token', data={'client_id':cid,'client_secret':sec,'grant_type':'authorization_code','code':code,'redirect_uri':ruri}, headers={'Content-Type':'application/x-www-form-urlencoded'})
    if r.status_code != 200: flash('Discord token exchange failed.','error'); return redirect(url_for('auth.login'))
    token = r.json().get('access_token')
    ur = req_lib.get('https://discord.com/api/users/@me', headers={'Authorization':f'Bearer {token}'})
    if ur.status_code != 200: flash('Failed to get Discord user.','error'); return redirect(url_for('auth.login'))
    du = ur.json(); did = du['id']; dname = du.get('username',''); demail = du.get('email','')
    user = User.query.filter_by(discord_id=did).first()
    if not user:
        if Settings.get('discord_allow_auto_register','true') != 'true':
            flash('Auto-registration disabled.','error'); return redirect(url_for('auth.login'))
        user = User.query.filter_by(email=demail).first()
        if user: user.discord_id = did; user.discord_username = dname
        else:
            base = ''.join(c for c in dname.lower() if c.isalnum())[:20] or 'user'
            uname = base; i = 1
            while User.query.filter_by(username=uname).first(): uname = f'{base}{i}'; i += 1
            user = User(username=uname, email=demail or f'{did}@discord.local', discord_id=did, discord_username=dname)
            user.generate_api_key(); db.session.add(user)
    user.last_login = user.last_active = datetime.utcnow(); db.session.commit()
    login_user(user)
    db.session.add(Notification(user_id=user.id, title='Discord Login', message=f'Signed in via Discord from {request.remote_addr}', type='info'))
    db.session.add(ActivityLog(user_id=user.id, action='login_discord', resource='auth 1', ip_address=request.remote_addr))
    db.session.commit()
    return redirect(url_for('main.dashboard'))

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user(); return redirect(url_for('main.index'))
