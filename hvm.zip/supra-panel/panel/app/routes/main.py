from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, current_app
from flask_login import login_required, current_user
from datetime import datetime
import os, secrets

from ..models import db, User, VPS, Node, Notification, ActivityLog, Settings, PortForward

main_bp = Blueprint('main', __name__)

def _gs():
    return {'site_name':Settings.get('site_name','Supra Hosting'),'footer_text':Settings.get('footer_text',''),
            'wallpaper_type':Settings.get('wallpaper_type','color'),'wallpaper_value':Settings.get('wallpaper_value','gradient-1'),
            'header_icon_url':Settings.get('header_icon_url',''),'bg_opacity':Settings.get('panel_bg_opacity','0.85')}

def _log(user, action, resource=None, details=None):
    db.session.add(ActivityLog(user_id=user.id, action=action, resource=resource, details=details, ip_address=request.remote_addr))
    db.session.commit()

@main_bp.route('/')
def index():
    if current_user.is_authenticated: return redirect(url_for('main.dashboard'))
    return render_template('index.html', **_gs())

@main_bp.route('/dashboard')
@login_required
def dashboard():
    current_user.last_active = datetime.utcnow(); db.session.commit()
    vps_list = VPS.query.filter_by(owner_id=current_user.id).all()
    running = sum(1 for v in vps_list if v.status=='running')
    stopped = sum(1 for v in vps_list if v.status=='stopped')
    suspended = sum(1 for v in vps_list if v.status=='suspended')
    total_cpu = sum(v.cpu_cores for v in vps_list); total_ram = sum(v.ram_gb for v in vps_list)
    notifs = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(4).all()
    nodes = Node.query.all()
    return render_template('dashboard/index.html', vps_list=vps_list, running=running, stopped=stopped,
        suspended=suspended, total_cpu=total_cpu, total_ram=total_ram, notifications=notifs, nodes=nodes,
        first_login=current_user.first_login, **_gs())

@main_bp.route('/dashboard/dismiss-firstlogin', methods=['POST'])
@login_required
def dismiss_first_login():
    current_user.first_login = False; db.session.commit(); return jsonify({'ok':True})

@main_bp.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_profile':
            nu = request.form.get('username','').strip(); ne = request.form.get('email','').strip().lower()
            if nu and nu != current_user.username:
                if User.query.filter_by(username=nu).first(): flash('Username taken.','error'); return redirect(url_for('main.profile'))
                current_user.username = nu
            if ne and ne != current_user.email:
                if User.query.filter_by(email=ne).first(): flash('Email in use.','error'); return redirect(url_for('main.profile'))
                current_user.email = ne
            cp = request.form.get('current_password',''); np = request.form.get('new_password','')
            cnp = request.form.get('confirm_new_password','')
            if np:
                if not current_user.check_password(cp): flash('Current password incorrect.','error'); return redirect(url_for('main.profile'))
                if np != cnp: flash('New passwords do not match.','error'); return redirect(url_for('main.profile'))
                current_user.set_password(np)
            if 'avatar' in request.files:
                f = request.files['avatar']
                if f and f.filename:
                    ext = f.filename.rsplit('.',1)[-1].lower()
                    if ext in ('png','jpg','jpeg','gif','webp'):
                        fname = f'avatar_{current_user.id}_{secrets.token_hex(4)}.{ext}'
                        path = os.path.join(current_app.config['UPLOAD_FOLDER'],'avatars',fname)
                        f.save(path); current_user.avatar_url = f'/static/uploads/avatars/{fname}'
            current_user.first_login = False; db.session.commit()
            db.session.add(Notification(user_id=current_user.id, title='Profile Updated', message='Your profile has been updated successfully.', type='success'))
            _log(current_user, 'update_profile'); db.session.commit()
            flash('Profile updated.','success')
        elif action == 'remove_avatar':
            current_user.avatar_url = ''; db.session.commit(); flash('Avatar removed.','success')
        elif action == 'regenerate_api_key':
            current_user.generate_api_key(); db.session.commit(); flash('API key regenerated.','success')
        return redirect(url_for('main.profile'))
    activity = ActivityLog.query.filter_by(user_id=current_user.id).order_by(ActivityLog.created_at.desc()).limit(20).all()
    return render_template('dashboard/profile.html', activity=activity, **_gs())

@main_bp.route('/notifications')
@login_required
def notifications():
    notifs = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template('dashboard/notifications.html', notifications=notifs, **_gs())

@main_bp.route('/notifications/mark-all-read', methods=['POST'])
@login_required
def mark_all_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read':True}); db.session.commit(); return jsonify({'ok':True})

@main_bp.route('/notifications/clear', methods=['POST'])
@login_required
def clear_notifications():
    Notification.query.filter_by(user_id=current_user.id).delete(); db.session.commit(); return jsonify({'ok':True})

@main_bp.route('/notifications/count')
@login_required
def notif_count():
    return jsonify({'count': Notification.query.filter_by(user_id=current_user.id, is_read=False).count()})

@main_bp.route('/port-forwarding')
@login_required
def port_forwarding():
    vps_list = VPS.query.filter_by(owner_id=current_user.id).all()
    ports = PortForward.query.join(VPS).filter(VPS.owner_id==current_user.id).all()
    return render_template('dashboard/port_forwarding.html', vps_list=vps_list, ports=ports, **_gs())

@main_bp.route('/port-forwarding/add', methods=['POST'])
@login_required
def add_port_forward():
    vps_id = request.form.get('vps_id', type=int); hp = request.form.get('host_port', type=int)
    cp = request.form.get('container_port', type=int); proto = request.form.get('protocol','tcp'); desc = request.form.get('description','')
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first()
    if not vps: flash('VPS not found.','error'); return redirect(url_for('main.port_forwarding'))
    used = PortForward.query.join(VPS).filter(VPS.owner_id==current_user.id).count()
    if used >= current_user.port_quota: flash(f'Port quota reached ({current_user.port_quota}).','error'); return redirect(url_for('main.port_forwarding'))
    db.session.add(PortForward(vps_id=vps_id, host_port=hp, container_port=cp, protocol=proto, description=desc))
    db.session.commit(); flash('Port forward added.','success'); return redirect(url_for('main.port_forwarding'))

@main_bp.route('/port-forwarding/delete/<int:pf_id>', methods=['POST'])
@login_required
def delete_port_forward(pf_id):
    pf = PortForward.query.get_or_404(pf_id)
    vps = VPS.query.get(pf.vps_id)
    if vps.owner_id != current_user.id and not current_user.is_admin: return jsonify({'error':'Unauthorized'}), 403
    db.session.delete(pf); db.session.commit(); return jsonify({'ok':True})
