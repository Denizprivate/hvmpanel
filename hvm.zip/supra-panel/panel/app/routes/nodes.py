from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
import psutil
from datetime import datetime
from ..models import db, Node, Settings

nodes_bp = Blueprint('nodes', __name__)

def _gs():
    return {'site_name':Settings.get('site_name','Supra Hosting'),'footer_text':Settings.get('footer_text',''),
            'wallpaper_type':Settings.get('wallpaper_type','color'),'wallpaper_value':Settings.get('wallpaper_value','gradient-1'),
            'header_icon_url':Settings.get('header_icon_url',''),'bg_opacity':Settings.get('panel_bg_opacity','0.85')}

@nodes_bp.route('/')
@login_required
def node_list():
    nodes = Node.query.all()
    return render_template('nodes/list.html', nodes=nodes, **_gs())

@nodes_bp.route('/<int:nid>/refresh', methods=['POST'])
@login_required
def refresh_node(nid):
    node = Node.query.get_or_404(nid)
    if node.is_local:
        node.cpu_usage = psutil.cpu_percent(interval=0.3)
        node.ram_usage = psutil.virtual_memory().percent
        node.disk_usage = psutil.disk_usage('/').percent
        node.status = 'online'
        node.last_seen = datetime.utcnow()
        db.session.commit()
    return jsonify({'cpu':node.cpu_usage,'ram':node.ram_usage,'disk':node.disk_usage,'status':node.status})
