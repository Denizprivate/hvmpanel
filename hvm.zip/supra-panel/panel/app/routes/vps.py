from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from datetime import datetime
import subprocess, threading, time, os, secrets

from ..models import db, VPS, Node, Notification, ActivityLog, Settings, OSIcon

vps_bp = Blueprint('vps', __name__)

def _gs():
    return {'site_name':Settings.get('site_name','Supra Hosting'),'footer_text':Settings.get('footer_text',''),
            'wallpaper_type':Settings.get('wallpaper_type','color'),'wallpaper_value':Settings.get('wallpaper_value','gradient-1'),
            'header_icon_url':Settings.get('header_icon_url',''),'bg_opacity':Settings.get('panel_bg_opacity','0.85')}

def run_cmd(cmd, timeout=120):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except: return '', 'Timeout', 1

def notify(user_id, title, message, ntype='info'):
    db.session.add(Notification(user_id=user_id, title=title, message=message, type=ntype))
    db.session.commit()

@vps_bp.route('/')
@login_required
def my_vps():
    vps_list = VPS.query.filter_by(owner_id=current_user.id).all()
    os_icons = OSIcon.query.all(); nodes = Node.query.filter_by(status='online').all()
    running = sum(1 for v in vps_list if v.status=='running')
    stopped = sum(1 for v in vps_list if v.status=='stopped')
    suspended = sum(1 for v in vps_list if v.status=='suspended')
    return render_template('vps/list.html', vps_list=vps_list, os_icons=os_icons, nodes=nodes,
        running=running, stopped=stopped, suspended=suspended, **_gs())

@vps_bp.route('/create', methods=['POST'])
@login_required
def create():
    name = request.form.get('name','').strip(); node_id = request.form.get('node_id', type=int)
    os_tmpl = request.form.get('os_template','ubuntu:22.04'); vps_type = request.form.get('vps_type','lxc')
    cpu_cores = request.form.get('cpu_cores',2,type=int); ram_gb = request.form.get('ram_gb',2,type=int)
    disk_gb = request.form.get('disk_gb',20,type=int)
    if not name or not node_id: return jsonify({'error':'Name and node required'}), 400
    node = Node.query.get_or_404(node_id)
    hostname = name.lower().replace(' ','-').replace('_','-')
    vps = VPS(name=name, hostname=hostname, owner_id=current_user.id, node_id=node_id,
              vps_type=vps_type, os_template=os_tmpl, cpu_cores=cpu_cores, ram_gb=ram_gb, disk_gb=disk_gb, status='creating')
    db.session.add(vps); db.session.commit(); vps_id = vps.id

    from flask import current_app
    app = current_app._get_current_object()
    def _create():
        with app.app_context():
            v = VPS.query.get(vps_id)
            try:
                if v.vps_type == 'lxc':
                    run_cmd(f'lxc init {os_tmpl} {hostname}', 180)
                    run_cmd(f'lxc config set {hostname} limits.cpu {cpu_cores}')
                    run_cmd(f'lxc config set {hostname} limits.memory {ram_gb}GB')
                    run_cmd(f'lxc start {hostname}', 60)
                    time.sleep(5)
                    out,_,_ = run_cmd(f"lxc list {hostname} -c 4 --format csv")
                    v.ip_address = out.strip().split('\n')[0].strip() or None
                    run_cmd(f'lxc exec {hostname} -- bash -c "apt-get update -qq && apt-get install -y -qq curl tmate > /dev/null 2>&1 && tmate -S /tmp/ts new-session -d && sleep 3 && tmate -S /tmp/ts display -p \'#{{tmate_ssh}}\' > /root/tmate_link.txt 2>&1 &"', 180)
                    run_cmd(f'lxc exec {hostname} -- bash -c "curl -sSf https://sshx.io/get | sh -s -- -q && sshx > /root/sshx.log 2>&1 &"', 60)
                elif v.vps_type == 'docker':
                    run_cmd('docker pull cruizba/ubuntu-dind', 300)
                    out,err,rc = run_cmd(f'docker run -d --runtime=sysbox-runc --name {hostname} --cpus={cpu_cores} --memory={ram_gb}g --restart unless-stopped cruizba/ubuntu-dind', 120)
                    if rc != 0:
                        run_cmd(f'docker run -d --privileged --name {hostname} --cpus={cpu_cores} --memory={ram_gb}g --restart unless-stopped cruizba/ubuntu-dind', 120)
                    time.sleep(3)
                    out,_,_ = run_cmd(f"docker inspect -f '{{{{.NetworkSettings.IPAddress}}}}' {hostname}")
                    v.ip_address = out.strip() or None
                v.status = 'running'
            except Exception as e:
                v.status = 'stopped'
            db.session.commit()
            notify(v.owner_id, 'VPS Ready', f'Your VPS "{v.name}" has been created!', 'success')
    threading.Thread(target=_create, daemon=True).start()
    return jsonify({'ok':True, 'vps_id':vps_id})

@vps_bp.route('/<int:vps_id>/status')
@login_required
def vps_status(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    return jsonify({'status':vps.status,'ip':vps.ip_address,'cpu':vps.cpu_usage,'ram':vps.ram_usage})

@vps_bp.route('/<int:vps_id>/manage')
@login_required
def manage(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    return render_template('vps/manage.html', vps=vps, **_gs())

@vps_bp.route('/<int:vps_id>/action', methods=['POST'])
@login_required
def vps_action(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    action = request.json.get('action')
    lxc_cmds = {'start':f'lxc start {vps.hostname}','stop':f'lxc stop {vps.hostname} --force','restart':f'lxc restart {vps.hostname}','delete':f'lxc delete {vps.hostname} --force'}
    docker_cmds = {'start':f'docker start {vps.hostname}','stop':f'docker stop {vps.hostname}','restart':f'docker restart {vps.hostname}','delete':f'docker rm -f {vps.hostname}'}
    cmds = lxc_cmds if vps.vps_type == 'lxc' else docker_cmds
    cmd = cmds.get(action)
    if not cmd: return jsonify({'error':'Unknown action'}), 400
    run_cmd(cmd)
    if action == 'start': vps.status = 'running'
    elif action == 'stop': vps.status = 'stopped'
    elif action == 'restart': vps.status = 'running'
    elif action == 'delete':
        db.session.delete(vps); db.session.commit(); return jsonify({'ok':True,'deleted':True})
    db.session.commit()
    return jsonify({'ok':True})

@vps_bp.route('/<int:vps_id>/generate-ssh', methods=['POST'])
@login_required
def generate_ssh(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    pfx = f'lxc exec {vps.hostname} --' if vps.vps_type=='lxc' else f'docker exec {vps.hostname}'
    run_cmd(f'{pfx} bash -c "command -v tmate || (apt-get update -qq && apt-get install -y -qq tmate)"', 90)
    run_cmd(f'{pfx} bash -c "pkill tmate 2>/dev/null; tmate -S /tmp/ts new-session -d && sleep 3 && tmate -S /tmp/ts display -p \'#{{tmate_ssh}}\' > /root/tmate_link.txt 2>&1 &"', 20)
    run_cmd(f'{pfx} bash -c "command -v sshx || curl -sSf https://sshx.io/get | sh -s -- -q"', 60)
    run_cmd(f'{pfx} bash -c "pkill sshx 2>/dev/null; sshx > /root/sshx.log 2>&1 &"', 10)
    time.sleep(5)
    tmate,_,_ = run_cmd(f'{pfx} cat /root/tmate_link.txt 2>/dev/null')
    sshx,_,_ = run_cmd(f'{pfx} grep -o "https://sshx.io[^ ]*" /root/sshx.log 2>/dev/null')
    db.session.add(Notification(user_id=current_user.id, title='SSH Session Created', message=f'SSH session created for {vps.name}', type='info'))
    db.session.commit()
    return jsonify({'ok':True,'tmate':tmate.strip(),'sshx':sshx.strip()})

@vps_bp.route('/<int:vps_id>/console')
@login_required
def console(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    db.session.add(Notification(user_id=current_user.id, title='Console Opened', message=f'Console session for {vps.name}', type='info'))
    db.session.commit()
    return render_template('vps/console.html', vps=vps, **_gs())

@vps_bp.route('/stats/<int:vps_id>')
@login_required
def stats(vps_id):
    vps = VPS.query.filter_by(id=vps_id, owner_id=current_user.id).first_or_404()
    cpu = ram = 0.0
    if vps.status == 'running' and vps.vps_type == 'docker':
        out,_,_ = run_cmd(f"docker stats {vps.hostname} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemPerc}}}}'")
        if out:
            parts = out.split()
            try: cpu = float(parts[0].replace('%',''))
            except: pass
            try: ram = float(parts[1].replace('%',''))
            except: pass
    vps.cpu_usage = cpu; vps.ram_usage = ram; db.session.commit()
    return jsonify({'cpu':cpu,'ram':ram,'status':vps.status})
