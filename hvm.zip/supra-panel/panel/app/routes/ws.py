import subprocess, threading, select
import paramiko

def register_ws(socketio):
    @socketio.on('connect', namespace='/console')
    def ws_connect(): pass

    @socketio.on('console_start', namespace='/console')
    def console_start(data):
        hostname = data.get('hostname','')
        vps_type = data.get('type','lxc')
        from flask import request as req
        sid = req.sid
        cmd = ['lxc','exec',hostname,'--','bash'] if vps_type=='lxc' else ['docker','exec','-it',hostname,'bash']
        def _run():
            try:
                proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                def _read():
                    while True:
                        line = proc.stdout.readline()
                        if not line: break
                        socketio.emit('console_output',{'data':line.decode('utf-8','replace')}, namespace='/console', room=sid)
                threading.Thread(target=_read, daemon=True).start()
            except Exception as e:
                socketio.emit('console_output',{'data':f'Error: {e}\r\n'}, namespace='/console', room=sid)
        threading.Thread(target=_run, daemon=True).start()

    @socketio.on('console_input', namespace='/console')
    def console_input(data): pass

    @socketio.on('ssh_connect', namespace='/ssh')
    def ssh_connect(data):
        host = data.get('host'); port = data.get('port',22)
        username = data.get('username','root'); password = data.get('password','')
        from flask import request as req
        sid = req.sid
        def _run():
            try:
                c = paramiko.SSHClient()
                c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                c.connect(host, port=port, username=username, password=password, timeout=10)
                chan = c.invoke_shell(); chan.settimeout(0.0)
                socketio.emit('ssh_output',{'data':f'Connected to {host}\r\n'}, namespace='/ssh', room=sid)
                while True:
                    r,_,_ = select.select([chan],[],[],0.1)
                    if r:
                        d = chan.recv(4096)
                        if not d: break
                        socketio.emit('ssh_output',{'data':d.decode('utf-8','replace')}, namespace='/ssh', room=sid)
                c.close()
            except Exception as e:
                socketio.emit('ssh_output',{'data':f'\r\nError: {e}\r\n'}, namespace='/ssh', room=sid)
        threading.Thread(target=_run, daemon=True).start()

    @socketio.on('ssh_input', namespace='/ssh')
    def ssh_input(data): pass
