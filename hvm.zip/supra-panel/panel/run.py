#!/usr/bin/env python3
import sys, os
from dotenv import load_dotenv
load_dotenv()

from app import create_app, socketio

app = create_app()

if __name__ == '__main__':
    if '--init-db' in sys.argv:
        with app.app_context():
            from app.models import db
            db.create_all()
            print('[✓] Database initialized.')
        sys.exit(0)
    port = int(os.environ.get('PANEL_PORT', 8888))
    host = os.environ.get('PANEL_HOST', '0.0.0.0')
    debug = os.environ.get('DEBUG','false').lower() == 'true'
    print(f'[✓] Supra Hosting Panel → http://{host}:{port}')
    socketio.run(app, host=host, port=port, debug=debug)
