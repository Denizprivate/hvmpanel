# 🚀 Supra Hosting Panel v2.0

Built on top of the HVM Panel codebase — enhanced with KVM support, live log streaming, and Discord bot integration.

## ⚡ Quick Install

```bash
# Upload this folder to your Ubuntu 22.04+ server, then:
sudo bash install.sh
```

**License Key:** `LVM-8F3K2-9XQPL-4Z7MN`

---

## 📋 What Gets Installed

| Step | Component | Details |
|------|-----------|---------|
| 1 | System packages | curl, wget, git, python3, sqlite3, build tools |
| 2 | LXC/LXD | With full `lxd init` (storage pool + bridge network) |
| 3 | Docker + Sysbox | Ubuntu-dind support, Sysbox runtime |
| 4 | KVM + libvirt | QEMU, virsh, cloud-init for VMs |
| 5 | Python venv | All Flask/SocketIO/paramiko deps |
| 6 | Panel files | Copied to /opt/supra-panel |
| 7 | Database | SQLite initialized with admin account |
| 8 | Systemd service | Auto-start on boot, logs to supra.log |

---

## 🌐 First Login

- **URL:** `http://YOUR_IP:8888`
- **Username:** `admin`  
- **Password:** `admin`
- **Activate license:** `http://YOUR_IP:8888/activate-license`
  - Key: `LVM-8F3K2-9XQPL-4Z7MN`

---

## 🤖 Discord Bot Commands

| Command | Description |
|---------|-------------|
| `/create lxc [name]` | Create LXC container |
| `/create docker [name]` | Create Docker (ubuntu-dind) container |
| `/create kvm [name]` | Create KVM virtual machine |
| `/list` | List your VPS |
| `/ssh [name]` | Get tmate + sshx access links |
| `/vps start/stop/restart <name>` | Power actions |
| `/status` | Node health stats |
| `/admincreate @user <type>` | Admin: create VPS for user |
| `/listall` | Admin: all VPS on panel |
| `/panelusers` | Admin: all panel users |
| `/announce <msg>` | Admin: broadcast message |

---

## 📊 Live Logs

**In the installer:** Choose option 4 — streams color-coded `supra.log` to your terminal.

**In the panel:** Admin → System Logs → real-time SSE stream with filter, pause, download.

**In terminal:**
```bash
tail -f /opt/supra-panel/supra.log
journalctl -u supra-panel -f
```

---

## 🔧 Services

```bash
systemctl status supra-panel   # Check panel
systemctl restart supra-panel  # Restart panel
systemctl status supra-bot     # Check bot
journalctl -u supra-panel -f   # Follow service logs
```

---

## 🗂️ File Structure

```
supra-panel/
├── install.sh          ← Run this first!
├── lvm.py              ← Main panel (9000+ lines)
├── api.py              ← REST API blueprint
├── node.py             ← Remote node agent
├── requirements.txt    ← Python deps
├── templates/          ← All HTML templates
│   ├── base.html       ← Video bg + glassmorphism
│   ├── vps_list.html   ← My VPS page
│   ├── vps_detail.html ← VPS manage/console
│   └── admin/          ← All admin pages
├── static/img/         ← Logo + favicon
└── bot/
    ├── bot.py          ← Discord bot
    └── requirements.txt
```

---

*Powered by Supra Hosting © 2026 | Version 2.0 | LXC + Docker + KVM*
