#!/usr/bin/env python3
"""
Supra Hosting — Discord Bot v2.0
Full panel integration: LXC + Docker + KVM
"""
import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio, aiohttp, os, secrets, string, psutil, json, subprocess, time
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

try:
    from tinydb import TinyDB, Query
    inv_db = TinyDB('supra_invites.json')
    inv_t  = inv_db.table('invites')
    mem_t  = inv_db.table('members')
    QUser  = Query()
    TINYDB_OK = True
except ImportError:
    TINYDB_OK = False
    print("Warning: tinydb not installed, invite tracking disabled")

TOKEN         = os.getenv('BOT_TOKEN', '')
ADMIN_IDS     = [int(x) for x in os.getenv('ADMIN_IDS', '0').split(',') if x.strip().isdigit()]
ADMIN_LOG_CH  = int(os.getenv('ADMIN_LOG_CHANNEL', 0))
PUBLIC_LOG_CH = int(os.getenv('PUBLIC_LOG_CHANNEL', 0))
PANEL_URL     = os.getenv('PANEL_URL', 'http://localhost:8888').rstrip('/')
PANEL_API_KEY = os.getenv('PANEL_API_KEY', '')
PREFIX        = os.getenv('PREFIX', '!')

inv_cache = {}

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.invites = True
bot = commands.Bot(command_prefix=[PREFIX, '-'], intents=intents, help_command=None)

# ── PANEL API ────────────────────────────────────────────────────────────────
async def panel_api(method: str, endpoint: str, data: dict = None, timeout: int = 30):
    url = f"{PANEL_URL}/api/v1/{endpoint.lstrip('/')}"
    headers = {'X-API-Key': PANEL_API_KEY, 'Content-Type': 'application/json', 'Accept': 'application/json'}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
        func = getattr(s, method.lower())
        kw = {'headers': headers}
        if data: kw['json'] = data
        try:
            async with func(url, **kw) as r:
                try:
                    return await r.json()
                except:
                    text = await r.text()
                    return {'error': f'Non-JSON response: {text[:200]}'}
        except aiohttp.ClientConnectorError:
            return {'error': f'Cannot connect to panel at {PANEL_URL}. Is it running?'}
        except asyncio.TimeoutError:
            return {'error': 'Panel request timed out'}
        except Exception as e:
            return {'error': str(e)}

async def panel_post_raw(endpoint: str, data: dict, timeout: int = 60):
    """POST to panel endpoints that aren't in the API blueprint"""
    url = f"{PANEL_URL}/{endpoint.lstrip('/')}"
    headers = {'X-API-Key': PANEL_API_KEY, 'Content-Type': 'application/json'}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
        try:
            async with s.post(url, json=data, headers=headers) as r:
                return await r.json()
        except Exception as e:
            return {'error': str(e), 'success': False}

async def arun(cmd: str, timeout: int = 30):
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return out.decode().strip(), err.decode().strip(), proc.returncode
    except asyncio.TimeoutError:
        return '', 'Command timed out', 1
    except Exception as e:
        return '', str(e), 1

async def send_log(title, desc, color, pub_title=None, pub_desc=None, pub_color=None):
    try:
        ch = bot.get_channel(ADMIN_LOG_CH)
        if ch: await ch.send(embed=discord.Embed(title=title, description=desc, color=color, timestamp=datetime.utcnow()))
        if pub_title:
            pch = bot.get_channel(PUBLIC_LOG_CH)
            if pch: await pch.send(embed=discord.Embed(title=pub_title, description=pub_desc, color=pub_color, timestamp=datetime.utcnow()))
    except Exception as e:
        print(f"Log error: {e}")

def emb(title='', desc='', color=0x3b82f6, fields=None):
    e = discord.Embed(title=title, description=desc, color=color, timestamp=datetime.utcnow())
    if fields:
        for n, v, i in fields: e.add_field(name=n, value=v, inline=i)
    e.set_footer(text='Supra Hosting')
    return e

TYPE_EMOJI = {'lxc': '🔷', 'docker': '🐳', 'kvm': '⚙️'}

# ── EVENTS ──────────────────────────────────────────────────────────────────
@bot.event
async def on_ready():
    print('═' * 54)
    print(f'  ✅  Supra Bot Online  : {bot.user.name}#{bot.user.discriminator}')
    print(f'  🔗  Gateway ID       : {bot.user.id}')
    print(f'  🌐  Panel URL        : {PANEL_URL}')
    print(f'  👑  Admin IDs        : {ADMIN_IDS}')
    print('═' * 54)
    for g in bot.guilds:
        try: inv_cache[g.id] = await g.invites()
        except: pass
    try:
        synced = await bot.tree.sync()
        print(f'  ✓   Synced {len(synced)} slash commands')
    except Exception as e:
        print(f'  ✗   Slash sync failed: {e}')

@bot.event
async def on_invite_create(invite):
    try: inv_cache[invite.guild.id] = await invite.guild.invites()
    except: pass

@bot.event
async def on_member_join(member):
    if not TINYDB_OK: return
    g = member.guild
    old = inv_cache.get(g.id, [])
    try: new = await g.invites()
    except: return
    used = next((i for o in old for i in new if o.code == i.code and i.uses > o.uses), None)
    inv_cache[g.id] = new
    if mem_t.get(QUser.member_id == str(member.id)): return
    if used and used.inviter:
        inv = inv_t.get(QUser.id == str(used.inviter.id)) or {'id': str(used.inviter.id), 'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
        age = (discord.utils.utcnow() - member.created_at).days
        if age < 7: inv['fakes'] += 1
        else: inv['joins'] += 1
        inv_t.upsert(inv, QUser.id == str(used.inviter.id))
        mem_t.upsert({'member_id': str(member.id), 'inviter_id': str(used.inviter.id)}, QUser.member_id == str(member.id))

@bot.event
async def on_member_remove(member):
    if not TINYDB_OK: return
    rec = mem_t.get(QUser.member_id == str(member.id))
    if rec:
        inv = inv_t.get(QUser.id == rec['inviter_id'])
        if inv: inv['leaves'] += 1; inv_t.upsert(inv, QUser.id == rec['inviter_id'])

# ── HELP ─────────────────────────────────────────────────────────────────────
class HelpSelect(discord.ui.Select):
    def __init__(self):
        opts = [
            discord.SelectOption(label='VPS Management', emoji='🖥️', description='Create LXC / Docker / KVM VPS'),
            discord.SelectOption(label='Power Actions',  emoji='⚡', description='Start, stop, restart'),
            discord.SelectOption(label='Access',         emoji='🔐', description='SSH & VNC access'),
            discord.SelectOption(label='Invites',        emoji='📊', description='Invite tracking'),
            discord.SelectOption(label='Admin',          emoji='👑', description='Admin-only commands'),
        ]
        super().__init__(placeholder='Select a category...', min_values=1, max_values=1, options=opts)

    async def callback(self, interaction: discord.Interaction):
        v = self.values[0]
        e = discord.Embed(title=f'Supra Hosting — {v}', color=0x3b82f6)
        if v == 'VPS Management':
            e.add_field(name='🔷 LXC', value='`/create lxc [name] [cpu] [ram] [disk]`\nFastest, lightest containers', inline=False)
            e.add_field(name='🐳 Docker', value='`/create docker [name] [cpu] [ram] [disk]`\nubuntu-dind with Sysbox runtime', inline=False)
            e.add_field(name='⚙️ KVM', value='`/create kvm [name] [cpu] [ram] [disk]`\nFull virtual machines, most isolated', inline=False)
            e.add_field(name='Other', value='`/list` — List your VPS\n`/delete [name]` — Delete a VPS', inline=False)
        elif v == 'Power Actions':
            e.add_field(name='Commands', value='`/vps start <name>`\n`/vps stop <name>`\n`/vps restart <name>`', inline=False)
        elif v == 'Access':
            e.add_field(name='LXC/Docker', value='`/ssh [name]` — Get tmate + sshx links', inline=False)
            e.add_field(name='KVM', value='`/kvminfo [name]` — Get VNC port + IP', inline=False)
            e.add_field(name='Panel', value='`/panel` — Get panel URL', inline=False)
        elif v == 'Invites':
            e.add_field(name='Commands', value='`/invites [@user]` — View invite stats', inline=False)
        elif v == 'Admin':
            if interaction.user.id in ADMIN_IDS:
                e.add_field(name='VPS', value='`/admincreate @user <lxc|docker|kvm> [name] [cpu] [ram] [disk]`\n`/listall` — All VPS on panel\n`/admindelete <name>` — Force delete any VPS', inline=False)
                e.add_field(name='Users', value='`/panelusers` — All panel users\n`/suspend <name>` — Suspend a VPS', inline=False)
                e.add_field(name='Other', value='`/announce <msg>` — Broadcast to Discord users\n`/addinvite @user <amount>` — Add invites', inline=False)
            else:
                e.description = '*You do not have admin permissions.*'
        await interaction.response.edit_message(embed=e)

class HelpView(discord.ui.View):
    def __init__(self): super().__init__(timeout=120); self.add_item(HelpSelect())

@bot.hybrid_command(description='Show help menu')
async def help(ctx):
    e = emb('Supra Hosting Bot', 'Choose a category below.\n\nSupports **LXC**, **Docker** (ubuntu-dind), and **KVM** virtual machines!')
    await ctx.send(embed=e, view=HelpView(), ephemeral=True)

# ── CREATE ──────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='create', description='Create a VPS — lxc, docker, or kvm')
@app_commands.describe(
    vps_type='Type: lxc, docker, or kvm',
    name='Custom hostname (optional)',
    cpu='CPU cores (default 2)',
    ram='RAM in GB (default 2)',
    disk='Disk in GB (default 20 for LXC/Docker, 40 for KVM)')
async def create(ctx, vps_type: str = 'lxc', name: str = None, cpu: int = 2, ram: int = 2, disk: int = None):
    vps_type = vps_type.lower().strip()
    if vps_type not in ('lxc', 'docker', 'kvm'):
        await ctx.send(embed=emb('❌ Invalid Type', f'Type must be `lxc`, `docker`, or `kvm`.\n\nExamples:\n`/create lxc`\n`/create docker`\n`/create kvm`', color=0xef4444), ephemeral=True)
        return

    if disk is None:
        disk = 40 if vps_type == 'kvm' else 20

    safe_name = ''.join(c for c in (ctx.author.name.lower()) if c.isalnum())[:8]
    auto_name = name or f'{safe_name}-{"".join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(5))}'
    auto_name = auto_name.lower().replace(' ', '-').replace('_', '-')[:40]

    te = TYPE_EMOJI.get(vps_type, '🖥️')
    msg = await ctx.send(embed=emb(
        f'{te} Creating {vps_type.upper()} VPS...',
        f'**Name:** `{auto_name}`\n**Resources:** {cpu} cores / {ram}GB RAM / {disk}GB disk\n*This may take up to 2 minutes for KVM...*'), ephemeral=True)

    # Choose endpoint
    if vps_type == 'kvm':
        d = await panel_post_raw('vps/create-kvm', {
            'name': auto_name, 'cpu': cpu, 'ram': ram, 'disk': disk,
            'os': 'ubuntu-22.04', 'node_id': 1}, timeout=120)
    else:
        d = await panel_api('POST', 'vps/create', {
            'name': auto_name, 'type': vps_type, 'cpu': cpu,
            'ram': ram, 'disk': disk, 'node_id': 1})

    success = d.get('success') or d.get('ok')

    if success:
        fields = [
            ('Name', f'`{auto_name}`', True),
            ('Type', vps_type.upper(), True),
            ('Resources', f'{cpu} cores / {ram}GB RAM / {disk}GB', True),
        ]
        if d.get('vnc_port'):
            fields.append(('VNC Port', f'`{d["vnc_port"]}`', True))
        fields.append(('Panel', f'[View on Panel]({PANEL_URL}/vps)', False))

        e = emb(f'✅ {vps_type.upper()} VPS Created!', '', color=0x10b981, fields=fields)
        if vps_type == 'kvm':
            e.add_field(name='ℹ️ KVM Note', value='VM is booting. Check the panel for IP after ~60s.\nDefault SSH: `root` / `root`', inline=False)
        await msg.edit(embed=e)
        try: await ctx.author.send(embed=e)
        except: pass
        await send_log(
            f'Bot: {vps_type.upper()} Created',
            f'**User:** {ctx.author.mention}\n**VPS:** `{auto_name}`\n**Type:** {vps_type}\n**Specs:** {cpu}c / {ram}GB / {disk}GB',
            0x10b981, f'{te} New {vps_type.upper()} Deployed!',
            f'{ctx.author.mention} deployed a **{vps_type.upper()}** server!', 0x10b981)
    else:
        err = d.get('error', 'Unknown error. Check panel logs.')
        await msg.edit(embed=emb('❌ Creation Failed', f'```{err[:300]}```\n\nCheck the panel logs for details.', color=0xef4444))

# ── LIST ─────────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='list', description='List your VPS instances')
async def list_vps(ctx):
    d = await panel_api('GET', 'vps')
    if 'error' in d:
        await ctx.send(embed=emb('❌ Error', d['error'], color=0xef4444), ephemeral=True); return
    if not d:
        await ctx.send(embed=emb('No VPS', 'You have no VPS instances. Use `/create` to deploy one!'), ephemeral=True); return

    e = discord.Embed(title=f'Your VPS Instances ({len(d)})', color=0x3b82f6, timestamp=datetime.utcnow())
    for vps in d[:10]:
        st  = '🟢' if vps['status'] == 'running' else '🔴' if vps['status'] == 'stopped' else '🟡'
        te  = TYPE_EMOJI.get(vps.get('type', 'lxc'), '🖥️')
        ip  = vps.get('ip') or 'No IP'
        vnc = f' | VNC: {vps["vnc_port"]}' if vps.get('vnc_port') else ''
        e.add_field(name=f'{st} {te} {vps["name"]}',
                    value=f'`{vps["status"]}` · {vps["cpu"]}c / {vps["ram"]}GB · {ip}{vnc}', inline=False)
    if len(d) > 10: e.set_footer(text=f'Showing 10/{len(d)} — see panel for all')
    e.add_field(name='🌐 Panel', value=f'[Open Panel]({PANEL_URL}/vps)', inline=False)
    await ctx.send(embed=e, ephemeral=True)

# ── VPS ACTIONS ──────────────────────────────────────────────────────────────
@bot.hybrid_command(name='vps', description='Control a VPS (start/stop/restart)')
@app_commands.describe(action='Action: start, stop, or restart', name='VPS name or ID')
async def vps_action(ctx, action: str, name: str):
    action = action.lower()
    if action not in ('start', 'stop', 'restart'):
        await ctx.send(embed=emb('❌ Invalid action', 'Use `start`, `stop`, or `restart`', color=0xef4444), ephemeral=True); return

    vps_list = await panel_api('GET', 'vps')
    if 'error' in vps_list:
        await ctx.send(embed=emb('❌ Error', vps_list['error'], color=0xef4444), ephemeral=True); return

    target = next((v for v in vps_list if v['name'] == name or str(v['id']) == name), None)
    if not target:
        await ctx.send(embed=emb('❌ Not Found', f'VPS `{name}` not found. Use `/list` to see your VPS.', color=0xef4444), ephemeral=True); return

    msg = await ctx.send(embed=emb(f'⚡ Running {action}...', f'VPS: `{target["name"]}`'), ephemeral=True)
    d = await panel_api('POST', f'vps/{target["id"]}/action', {'action': action})

    if d.get('ok') or d.get('success'):
        color = 0x10b981 if action == 'start' else 0xef4444 if action == 'stop' else 0xf59e0b
        await msg.edit(embed=emb(f'✅ {action.title()} successful', f'`{target["name"]}` → `{action}ed`', color=color))
        await send_log(f'Bot: VPS {action.title()}', f'**User:** {ctx.author.mention}\n**VPS:** `{target["name"]}`', color)
    else:
        await msg.edit(embed=emb('❌ Action Failed', d.get('error', 'Unknown error'), color=0xef4444))

# ── SSH ──────────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='ssh', description='Generate tmate + sshx sessions for LXC/Docker VPS')
@app_commands.describe(name='VPS name (optional if you only have one)')
async def ssh(ctx, name: str = None):
    vps_list = await panel_api('GET', 'vps')
    if 'error' in vps_list:
        await ctx.send(embed=emb('❌ Error', vps_list['error'], color=0xef4444), ephemeral=True); return

    if name:
        target = next((v for v in vps_list if v['name'] == name or str(v['id']) == name), None)
    elif len(vps_list) == 1:
        target = vps_list[0]
    elif len(vps_list) == 0:
        await ctx.send(embed=emb('No VPS', 'You have no VPS. Use `/create` first.'), ephemeral=True); return
    else:
        names = '\n'.join([f'`{v["name"]}` ({TYPE_EMOJI.get(v.get("type","lxc"),"🖥️")} {v.get("type","lxc").upper()})' for v in vps_list[:10]])
        await ctx.send(embed=emb('Specify a VPS', f'You have multiple VPS:\n{names}\n\nUsage: `/ssh <name>`', color=0xf59e0b), ephemeral=True); return

    if not target:
        await ctx.send(embed=emb('❌ Not Found', f'VPS `{name}` not found.', color=0xef4444), ephemeral=True); return

    if target.get('type') == 'kvm':
        await ctx.send(embed=emb('⚙️ KVM VM — Use `/kvminfo`',
            f'KVM VMs use VNC for console access, not tmate/sshx.\n\nUse `/kvminfo {target["name"]}` for connection details.', color=0xf59e0b), ephemeral=True)
        return

    msg = await ctx.send(embed=emb('🔑 Generating SSH Sessions...', 'Installing tmate & sshx on the VPS. Please wait ~30 seconds...'), ephemeral=True)

    h   = target['name']
    pfx = f'lxc exec {h} --' if target.get('type', 'lxc') == 'lxc' else f'docker exec {h}'

    # Check if sessions already exist
    out_t, _, _ = await arun(f"{pfx} cat /root/tmate_link.txt 2>/dev/null")
    out_s, _, _ = await arun(f"{pfx} grep -o 'https://sshx.io[^ ]*' /root/sshx.log 2>/dev/null | tail -1")

    if not out_t.strip() or 'ssh' not in out_t:
        # Install and generate fresh sessions
        await arun(f"{pfx} bash -c 'apt-get update -qq -y && apt-get install -y -qq curl tmate 2>/dev/null'", timeout=90)
        await arun(f"{pfx} bash -c 'pkill tmate 2>/dev/null; rm -f /tmp/ts; tmate -S /tmp/ts new-session -d && sleep 4 && tmate -S /tmp/ts display -p \"#{{tmate_ssh}}\" > /root/tmate_link.txt 2>&1 &'", timeout=20)
        await arun(f"{pfx} bash -c 'command -v sshx || curl -sSf https://sshx.io/get | sh -s -- -q 2>/dev/null'", timeout=60)
        await arun(f"{pfx} bash -c 'pkill sshx 2>/dev/null; sshx > /root/sshx.log 2>&1 &'", timeout=10)
        await asyncio.sleep(6)
        out_t, _, _ = await arun(f"{pfx} cat /root/tmate_link.txt 2>/dev/null")
        out_s, _, _ = await arun(f"{pfx} grep -o 'https://sshx.io[^ ]*' /root/sshx.log 2>/dev/null | tail -1")

    e = discord.Embed(title=f'🔑 SSH Sessions — `{h}`', color=0x3b82f6, timestamp=datetime.utcnow())
    if out_t.strip() and 'ssh' in out_t:
        e.add_field(name='tmate (terminal)', value=f'```{out_t.strip()}```', inline=False)
    else:
        e.add_field(name='tmate', value='Not available (VPS may be offline)', inline=False)

    if out_s.strip():
        e.add_field(name='sshx (web browser)', value=out_s.strip(), inline=False)
        e.add_field(name='🌐 Open Web Console', value=f'[Click here to open]({out_s.strip()})', inline=False)
    else:
        e.add_field(name='sshx', value='Not available', inline=False)

    e.add_field(name='📊 Panel Console', value=f'[Open in Panel]({PANEL_URL}/vps)', inline=False)
    e.set_footer(text='Sessions reset when VPS restarts')
    await msg.edit(embed=e)
    try: await ctx.author.send(embed=e)
    except: pass

# ── KVM INFO ─────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='kvminfo', description='Get VNC/SSH info for a KVM virtual machine')
@app_commands.describe(name='KVM VPS name')
async def kvminfo(ctx, name: str = None):
    vps_list = await panel_api('GET', 'vps')
    if 'error' in vps_list:
        await ctx.send(embed=emb('❌ Error', vps_list['error'], color=0xef4444), ephemeral=True); return

    kvm_list = [v for v in vps_list if v.get('type') == 'kvm']
    if not kvm_list:
        await ctx.send(embed=emb('No KVM VMs', 'You have no KVM virtual machines. Use `/create kvm` to create one.'), ephemeral=True); return

    if name:
        target = next((v for v in kvm_list if v['name'] == name or str(v['id']) == name), None)
    elif len(kvm_list) == 1:
        target = kvm_list[0]
    else:
        names = '\n'.join([f'`{v["name"]}`' for v in kvm_list[:10]])
        await ctx.send(embed=emb('Specify a KVM VM', f'Your KVM VMs:\n{names}\n\nUsage: `/kvminfo <name>`', color=0xf59e0b), ephemeral=True); return

    if not target:
        await ctx.send(embed=emb('❌ Not Found', f'KVM VM `{name}` not found.', color=0xef4444), ephemeral=True); return

    # Get VNC info from panel
    d = await panel_post_raw(f'vps/{target["id"]}/kvm-info', {})
    vnc_port = d.get('vnc_port', 'N/A')
    vnc_pass = d.get('vnc_pass', 'N/A')
    ip       = d.get('ip') or target.get('ip') or 'Pending...'
    state    = d.get('state', target.get('status', 'unknown'))

    server_ip, _, _ = await arun("curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}'")
    server_ip = server_ip.strip() or 'YOUR_SERVER_IP'

    e = discord.Embed(title=f'⚙️ KVM VM Info — `{target["name"]}`', color=0xf59e0b, timestamp=datetime.utcnow())
    e.add_field(name='Status', value=state, inline=True)
    e.add_field(name='IP Address', value=f'`{ip}`', inline=True)
    e.add_field(name='VNC Port', value=f'`{vnc_port}`', inline=True)
    e.add_field(name='VNC Password', value=f'||`{vnc_pass}`||', inline=True)
    e.add_field(name='VNC Connection', value=f'`{server_ip}:{vnc_port}`\nUse a VNC viewer like RealVNC or TigerVNC', inline=False)
    e.add_field(name='SSH (after boot)', value=f'```ssh root@{ip}\nPassword: root```', inline=False)
    e.set_footer(text='KVM VMs take ~60s to fully boot')
    await ctx.send(embed=e, ephemeral=True)

# ── STATUS ───────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='status', description='Show node health and resource usage')
async def status(ctx):
    d = await panel_api('GET', 'nodes')
    cpu = psutil.cpu_percent(interval=0.5)
    ram = psutil.virtual_memory()

    e = discord.Embed(title='📊 Node Status', color=0x3b82f6, timestamp=datetime.utcnow())
    e.add_field(name='Host CPU', value=f'{cpu:.1f}%', inline=True)
    e.add_field(name='Host RAM', value=f'{ram.percent:.1f}% ({ram.used//1024//1024}MB/{ram.total//1024//1024}MB)', inline=True)

    if isinstance(d, list):
        for node in d:
            st = '🟢 Online' if node['status'] == 'online' else '🔴 Offline'
            e.add_field(name=f'{st} — {node["name"]}',
                        value=f'CPU: {node["cpu"]:.1f}% | RAM: {node["ram"]:.1f}% | VPS: {node["vps_count"]}', inline=False)
    else:
        e.add_field(name='Nodes', value=f'Could not fetch node data: {d.get("error","unknown")}', inline=False)

    e.add_field(name='Panel', value=f'[Open Panel]({PANEL_URL})', inline=False)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(name='panel', description='Get the panel URL')
async def panel(ctx):
    e = emb('🌐 Supra Hosting Panel', f'Access your control panel:\n{PANEL_URL}\n\nLogin: `admin` / `admin` (change after first login!)')
    await ctx.send(embed=e, ephemeral=True)

# ── INVITES ──────────────────────────────────────────────────────────────────
@bot.hybrid_command(name='invites', description='Check invite statistics')
@app_commands.describe(target='User to check (leave empty for yourself)')
async def invites(ctx, target: discord.User = None):
    if not TINYDB_OK:
        await ctx.send(embed=emb('❌ Error', 'tinydb not installed. Run: `pip install tinydb`', color=0xef4444), ephemeral=True); return
    target = target or ctx.author
    inv = inv_t.get(QUser.id == str(target.id)) or {'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
    valid = inv['joins'] + inv.get('manual', 0) - inv['leaves']
    e = discord.Embed(color=0x3b82f6, timestamp=datetime.utcnow())
    e.set_author(name=f'{target.name}\'s Invites', icon_url=target.display_avatar.url)
    e.description = (f'**{valid}** valid invites\n\n'
                     f'✅ Joins: **{inv["joins"] + inv.get("manual", 0)}**\n'
                     f'❌ Left: **{inv["leaves"]}**\n'
                     f'⚠️ Fake: **{inv.get("fakes", 0)}**')
    await ctx.send(embed=e, ephemeral=True)

# ── ADMIN ─────────────────────────────────────────────────────────────────────
def admin_only():
    async def predicate(ctx):
        if ctx.author.id not in ADMIN_IDS:
            await ctx.send(embed=emb('❌ Admin Only', 'This command requires admin permissions.', color=0xef4444), ephemeral=True)
            return False
        return True
    return commands.check(predicate)

@bot.hybrid_command(name='admincreate', description='[Admin] Create a VPS for a specific user')
@admin_only()
@app_commands.describe(user='Target Discord user', vps_type='lxc, docker, or kvm', name='Custom name', cpu='CPU cores', ram='RAM GB', disk='Disk GB')
async def admincreate(ctx, user: discord.User, vps_type: str = 'lxc', name: str = None, cpu: int = 2, ram: int = 2, disk: int = None):
    vps_type = vps_type.lower()
    if vps_type not in ('lxc', 'docker', 'kvm'):
        await ctx.send(embed=emb('❌ Error', 'Type must be lxc, docker, or kvm', color=0xef4444), ephemeral=True); return

    if disk is None:
        disk = 40 if vps_type == 'kvm' else 20

    safe = ''.join(c for c in user.name.lower() if c.isalnum())[:8]
    auto_name = (name or f'{safe}-{"".join(secrets.choice(string.ascii_lowercase+string.digits) for _ in range(5))}').lower().replace(' ','-')[:40]
    te = TYPE_EMOJI.get(vps_type, '🖥️')

    msg = await ctx.send(embed=emb(f'{te} Creating {vps_type.upper()} for {user.name}...'), ephemeral=True)

    if vps_type == 'kvm':
        d = await panel_post_raw('vps/create-kvm', {'name': auto_name, 'cpu': cpu, 'ram': ram, 'disk': disk, 'os': 'ubuntu-22.04', 'node_id': 1}, timeout=120)
    else:
        d = await panel_api('POST', 'vps/create', {'name': auto_name, 'type': vps_type, 'cpu': cpu, 'ram': ram, 'disk': disk, 'node_id': 1})

    if d.get('success') or d.get('ok'):
        fields = [('VPS', f'`{auto_name}`', True), ('Type', vps_type.upper(), True), ('Specs', f'{cpu}c/{ram}GB/{disk}GB', True)]
        if d.get('vnc_port'): fields.append(('VNC Port', f'`{d["vnc_port"]}`', True))
        fields.append(('Panel', f'[View]({PANEL_URL}/admin/vps)', False))
        e = emb(f'✅ {vps_type.upper()} Created for {user.name}', '', color=0x10b981, fields=fields)
        await msg.edit(embed=e)
        try:
            await user.send(embed=discord.Embed(title=f'🎉 Your {vps_type.upper()} VPS is Ready!',
                description=f'**Name:** `{auto_name}`\n**Specs:** {cpu} cores / {ram}GB RAM / {disk}GB disk\n\n[Open Panel]({PANEL_URL}/vps)', color=0x10b981))
        except: pass
        await send_log(f'Admin: {vps_type.upper()} Created',
            f'**Admin:** {ctx.author.mention}\n**User:** {user.mention}\n**VPS:** `{auto_name}`\n**Specs:** {cpu}c/{ram}GB/{disk}GB', 0x10b981)
    else:
        await msg.edit(embed=emb('❌ Failed', d.get('error', 'Unknown error'), color=0xef4444))

@bot.hybrid_command(name='listall', description='[Admin] List all VPS on the panel')
@admin_only()
async def listall(ctx):
    d = await panel_api('GET', 'vps')
    if not isinstance(d, list):
        await ctx.send(embed=emb('❌ Error', d.get('error', 'Failed to fetch'), color=0xef4444), ephemeral=True); return

    e = discord.Embed(title=f'All VPS — {len(d)} total', color=0x3b82f6, timestamp=datetime.utcnow())
    for vps in d[:20]:
        st = '🟢' if vps['status'] == 'running' else '🔴'
        te = TYPE_EMOJI.get(vps.get('type','lxc'), '🖥️')
        e.add_field(name=f'{st} {te} {vps["name"]}',
                    value=f'`{vps["status"]}` · {vps["cpu"]}c/{vps["ram"]}GB · Owner: {vps.get("owner_id", "?")}', inline=False)
    if len(d) > 20: e.set_footer(text=f'Showing 20/{len(d)} VPS. See panel for full list.')
    e.add_field(name='Panel', value=f'[View All VPS]({PANEL_URL}/admin/vps)', inline=False)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(name='panelusers', description='[Admin] List all panel users')
@admin_only()
async def panelusers(ctx):
    d = await panel_api('GET', 'users')
    if not isinstance(d, list):
        await ctx.send(embed=emb('❌ Error', d.get('error', 'Failed'), color=0xef4444), ephemeral=True); return

    e = discord.Embed(title=f'Panel Users — {len(d)} total', color=0x3b82f6, timestamp=datetime.utcnow())
    for u in d[:15]:
        role_e = '👑' if 'main_admin' in u.get('role','') else '🔧' if 'admin' in u.get('role','') else '👤'
        e.add_field(name=f'{role_e} {u["username"]}',
                    value=f'Email: {u["email"][:20]}...\nVPS: {u.get("vps_count",0)} | Role: {u.get("role","user")}', inline=True)
    e.add_field(name='Panel', value=f'[Manage Users]({PANEL_URL}/admin/users)', inline=False)
    await ctx.send(embed=e, ephemeral=True)

@bot.hybrid_command(name='announce', description='[Admin] Send announcement to all Discord-linked users')
@admin_only()
@app_commands.describe(message='Announcement message to send')
async def announce(ctx, *, message: str):
    d = await panel_api('GET', 'users')
    sent = 0; failed = 0
    for u in (d if isinstance(d, list) else []):
        if u.get('discord_id'):
            try:
                du = await bot.fetch_user(int(u['discord_id']))
                e = discord.Embed(title='📢 Supra Hosting Announcement', description=message, color=0xf59e0b, timestamp=datetime.utcnow())
                e.set_footer(text='Supra Hosting Admin Broadcast')
                await du.send(embed=e)
                sent += 1
            except: failed += 1
    await ctx.send(embed=emb('✅ Announcement Sent', f'Delivered to **{sent}** users. Failed: {failed}', color=0x10b981), ephemeral=True)
    await send_log('Admin: Announcement', f'**Admin:** {ctx.author.mention}\n**Msg:** {message[:200]}\n**Sent:** {sent} | **Failed:** {failed}', 0xf59e0b)

@bot.hybrid_command(name='addinvite', description='[Admin] Add manual invites to a user')
@admin_only()
@app_commands.describe(target='Target user', amount='Invites to add (use negative to remove)')
async def addinvite(ctx, target: discord.User, amount: int):
    if not TINYDB_OK:
        await ctx.send(embed=emb('❌ Error', 'tinydb not installed', color=0xef4444), ephemeral=True); return
    inv = inv_t.get(QUser.id == str(target.id)) or {'id': str(target.id), 'joins': 0, 'leaves': 0, 'fakes': 0, 'manual': 0}
    inv['manual'] = inv.get('manual', 0) + amount
    inv_t.upsert(inv, QUser.id == str(target.id))
    valid = inv['joins'] + inv['manual'] - inv['leaves']
    await ctx.send(embed=emb('✅ Invites Updated', f'Added `{amount:+}` invites to {target.mention}.\nNew total: **{valid}** valid invites', color=0x10b981), ephemeral=True)

@bot.command()
async def sync(ctx):
    if ctx.author.id not in ADMIN_IDS: return
    synced = await bot.tree.sync()
    await ctx.send(embed=emb('✅ Synced', f'Synced {len(synced)} slash commands globally!', color=0x10b981))

# ── RUN ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    if not TOKEN:
        print('❌  BOT_TOKEN not set in .env')
        print('   Create a .env file with: BOT_TOKEN=your_token_here')
        exit(1)
    print(f'Starting Supra Hosting Bot...')
    bot.run(TOKEN, reconnect=True)
