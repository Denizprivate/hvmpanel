#!/bin/bash
set -euo pipefail
trap 'echo -e "\n${RED}✗  Error on line $LINENO. Check: ${LOG_FILE}${RESET}"; exit 1' ERR

RED='\033[0;31m';GREEN='\033[0;32m';YELLOW='\033[1;33m';BLUE='\033[0;34m'
CYAN='\033[0;36m';WHITE='\033[1;37m';DIM='\033[2m';RESET='\033[0m'
VALID_LICENSE="LVM-8F3K2-9XQPL-4Z7MN"
INSTALL_DIR="/opt/supra-panel"
BOT_DIR="/opt/supra-bot"
PANEL_PORT=8888
LOG_FILE="/var/log/supra-install.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ok()   { echo -e "  ${GREEN}✓${RESET}  $*"; echo "[OK] $*"   >> "$LOG_FILE"; }
warn() { echo -e "  ${YELLOW}⚠${RESET}  $*"; echo "[WN] $*"   >> "$LOG_FILE"; }
info() { echo -e "  ${CYAN}›${RESET}  $*";  echo "[IN] $*"   >> "$LOG_FILE"; }
step() { echo -e "\n  ${WHITE}$*${RESET}";  echo "[ST] $*"   >> "$LOG_FILE"; }

spinner() {
  local pid=$1 msg=$2 spin='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏' i=0
  while kill -0 "$pid" 2>/dev/null; do
    i=$(( (i+1)%10 )); printf "\r  ${CYAN}${spin:$i:1}${RESET}  $msg"; sleep 0.1
  done
  wait "$pid" 2>/dev/null && printf "\r  ${GREEN}✓${RESET}  $msg\n" || printf "\r  ${YELLOW}⚠${RESET}  $msg\n"
  return 0
}
rsh() { local msg="$1"; shift; (bash -c "$*" >>"$LOG_FILE" 2>&1)& spinner $! "$msg"; }

print_banner() {
  clear
  echo -e "${BLUE}"
  echo "  ╔══════════════════════════════════════════════════════════════╗"
  echo "  ║   ███████╗██╗   ██╗██████╗ ██████╗  █████╗                 ║"
  echo "  ║   ██╔════╝██║   ██║██╔══██╗██╔══██╗██╔══██╗                ║"
  echo "  ║   ███████╗██║   ██║██████╔╝██████╔╝███████║                ║"
  echo "  ║   ╚════██║██║   ██║██╔═══╝ ██╔══██╗██╔══██║                ║"
  echo "  ║   ███████║╚██████╔╝██║     ██║  ██║██║  ██║                ║"
  echo "  ║   ╚══════╝ ╚═════╝ ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝                ║"
  echo -e "  ║    ${WHITE}HOSTING PANEL${BLUE}  ·  ${CYAN}LXC + Docker + KVM  ·  Port ${PANEL_PORT}${BLUE}      ║"
  echo "  ╚══════════════════════════════════════════════════════════════╝"
  echo -e "${RESET}"
}

license_check() {
  print_banner
  echo -e "  ${WHITE}  LICENSE VERIFICATION${RESET}\n"
  local attempts=0
  while true; do
    attempts=$((attempts+1)); [ $attempts -gt 3 ] && echo -e "\n  ${RED}Too many failed attempts.${RESET}" && exit 1
    echo -ne "  ${CYAN}▸${RESET}  License Key: "; read -r key
    key=$(echo "$key"|tr '[:lower:]' '[:upper:]'|xargs)
    if [ "$key" = "$VALID_LICENSE" ]; then
      echo ""; ok "License validated!"
      echo -e "  ${CYAN}  Access granted — welcome back, ${WHITE}Supra Hosting${RESET}${CYAN}. Good to meet you!${RESET}"
      echo -e "  ${DIM}  We are now directing you to the menu...${RESET}"; sleep 2; break
    else
      echo -e "  ${RED}✗  Invalid license key.${RESET}"
      [ $attempts -lt 3 ] && echo -e "  ${DIM}  Attempts remaining: $((3-attempts))${RESET}\n"
    fi
  done
}

show_menu() {
  while true; do
    print_banner
    echo -e "  ${WHITE}  MAIN MENU${RESET}\n"
    echo -e "    ${CYAN}1${RESET}  ${WHITE}Install Panel${RESET}           ${DIM}LXC + Docker + KVM + Web Panel on :${PANEL_PORT}${RESET}"
    echo -e "    ${CYAN}2${RESET}  ${WHITE}Install Discord Bot${RESET}      ${DIM}/create kvm|docker|lxc from Discord${RESET}"
    echo -e "    ${CYAN}3${RESET}  ${WHITE}Install Both${RESET}             ${DIM}Panel + Bot (complete setup)${RESET}"
    echo -e "    ${CYAN}4${RESET}  ${WHITE}Show Live Logs${RESET}           ${DIM}Color-coded stream of supra.log${RESET}"
    echo -e "    ${CYAN}5${RESET}  ${WHITE}Panel Status${RESET}             ${DIM}Service + LXD + Docker + KVM status${RESET}"
    echo -e "    ${CYAN}6${RESET}  ${WHITE}Restart Panel${RESET}            ${DIM}Restart the panel service${RESET}"
    echo -e "    ${CYAN}7${RESET}  ${WHITE}Update Panel${RESET}             ${DIM}Sync files + restart${RESET}"
    echo -e "    ${CYAN}8${RESET}  ${WHITE}Uninstall${RESET}                ${DIM}Remove everything${RESET}"
    echo -e "    ${CYAN}9${RESET}  ${WHITE}Exit${RESET}\n"
    echo -ne "  ${CYAN}▸${RESET}  Choose [1-9]: "; read -r c
    case $c in
      1) install_panel ;; 2) install_bot ;; 3) install_panel && install_bot ;;
      4) show_logs ;;     5) panel_status ;; 6) restart_panel ;;
      7) update_panel ;;  8) do_uninstall ;;
      9) echo -e "\n  ${DIM}Goodbye! — Supra Hosting${RESET}\n"; exit 0 ;;
      *) warn "Invalid option."; sleep 1 ;;
    esac
  done
}

install_panel() {
  print_banner
  echo -e "  ${WHITE}  FULL INSTALLATION — LXC + Docker + KVM + Panel${RESET}\n"
  echo -ne "  ${CYAN}▸${RESET}  Proceed? [Y/n]: "; read -r c; [[ "$c" =~ ^[Nn] ]] && return

  touch "$LOG_FILE"; trap '' ERR

  # 1 — Base packages
  step "[1/8] System packages"
  rsh "apt-get update" "DEBIAN_FRONTEND=noninteractive apt-get update -y"
  rsh "Installing curl, wget, git, python3, sqlite3, snapd, build tools..." \
    "DEBIAN_FRONTEND=noninteractive apt-get install -y \
     curl wget git python3 python3-pip python3-venv python3-dev \
     sqlite3 snapd software-properties-common ca-certificates \
     lsb-release apt-transport-https gnupg2 net-tools htop \
     unzip rsync jq build-essential libssl-dev libffi-dev \
     cloud-image-utils genisoimage iptables-persistent 2>/dev/null || true"

  # 2 — LXC/LXD
  step "[2/8] LXC / LXD"
  if command -v lxc >/dev/null 2>&1; then
    ok "LXC already installed."
  else
    rsh "Installing LXD via snap" "snap install lxd 2>&1"
    rsh "Symlinking lxc/lxd binaries" \
      "ln -sf /snap/bin/lxd /usr/local/bin/lxd 2>/dev/null; ln -sf /snap/bin/lxc /usr/local/bin/lxc 2>/dev/null; true"
  fi

  # Full LXD preseed — no interactive prompts, no errors
  rsh "Initializing LXD (storage pool + bridge network)" \
    'if lxd info 2>/dev/null | grep -q "server_name"; then
       echo "LXD already initialized."
     else
       cat > /tmp/lxd_preseed.yaml << YML
config: {}
cluster: null
networks:
- config:
    ipv4.address: 10.200.0.1/24
    ipv4.nat: "true"
    ipv6.address: none
  description: ""
  name: lxdbr0
  type: bridge
storage_pools:
- config: {}
  description: ""
  driver: dir
  name: default
profiles:
- config: {}
  description: ""
  devices:
    eth0:
      name: eth0
      network: lxdbr0
      type: nic
    root:
      path: /
      pool: default
      type: disk
  name: default
YML
       lxd init --preseed < /tmp/lxd_preseed.yaml 2>&1 || lxd init --auto 2>&1 || true
     fi'

  rsh "Configuring LXD groups" \
    "usermod -aG lxd root 2>/dev/null; usermod -aG lxd www-data 2>/dev/null || true"

  # Pre-pull the default ubuntu image so first VPS creation is fast
  rsh "Pre-pulling Ubuntu 22.04 LXC image (background)" \
    "nohup lxc image copy ubuntu:22.04 local: --alias ubuntu-22.04 >/dev/null 2>&1 &"

  # 3 — Docker
  step "[3/8] Docker Engine"
  if command -v docker >/dev/null 2>&1; then
    ok "Docker already installed."
  else
    rsh "Adding Docker apt repository" \
      "install -m 0755 -d /etc/apt/keyrings; \
       curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg 2>/dev/null; \
       chmod a+r /etc/apt/keyrings/docker.gpg; \
       echo \"deb [arch=\$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \$(. /etc/os-release && echo \$VERSION_CODENAME) stable\" > /etc/apt/sources.list.d/docker.list; \
       DEBIAN_FRONTEND=noninteractive apt-get update -y"
    rsh "Installing Docker CE + compose plugin" \
      "DEBIAN_FRONTEND=noninteractive apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>&1"
    rsh "Enabling Docker service" "systemctl enable --now docker"
  fi
  rsh "Docker group setup" "usermod -aG docker root 2>/dev/null; usermod -aG docker www-data 2>/dev/null || true"

  rsh "Installing Sysbox (ubuntu-dind support)" \
    'ARCH=$(dpkg --print-architecture)
     VER="0.6.4"
     DEB="sysbox-ce_${VER}-0.linux_${ARCH}.deb"
     wget -q "https://downloads.nestybox.com/sysbox/releases/v${VER}/${DEB}" -O /tmp/sysbox.deb 2>/dev/null || true
     if [ -s /tmp/sysbox.deb ]; then
       DEBIAN_FRONTEND=noninteractive dpkg -i /tmp/sysbox.deb 2>&1 || \
       DEBIAN_FRONTEND=noninteractive apt-get install -f -y 2>&1 || true
     else
       echo "Sysbox download unavailable — Docker VPS will use --privileged mode"
     fi'

  # Write Docker daemon config
  rsh "Writing Docker daemon.json" \
    'cat > /etc/docker/daemon.json << JSON
{
  "runtimes": {"sysbox-runc": {"path": "/usr/bin/sysbox-runc"}},
  "default-runtime": "runc",
  "log-driver": "json-file",
  "log-opts": {"max-size": "10m", "max-file": "3"}
}
JSON
systemctl restart docker 2>/dev/null || true'

  # Pre-pull ubuntu-dind so Docker VPS creation is instant
  rsh "Pre-pulling ubuntu-dind image (background)" \
    "nohup docker pull cruizba/ubuntu-dind >/dev/null 2>&1 &"

  # 4 — KVM
  step "[4/8] KVM + QEMU + libvirt"
  rsh "Installing KVM packages" \
    "DEBIAN_FRONTEND=noninteractive apt-get install -y \
     qemu-kvm qemu-utils libvirt-daemon-system libvirt-clients \
     virtinst bridge-utils cpu-checker cloud-utils ovmf 2>&1 || \
     DEBIAN_FRONTEND=noninteractive apt-get install -y \
     qemu-kvm libvirt-daemon-system libvirt-clients virtinst 2>&1 || true"

  rsh "Enabling libvirtd" "systemctl enable --now libvirtd 2>/dev/null || true"
  rsh "Configuring KVM groups + permissions" \
    "usermod -aG libvirt,kvm root 2>/dev/null; \
     usermod -aG libvirt,kvm www-data 2>/dev/null || true; \
     chmod 666 /dev/kvm 2>/dev/null || true"
  rsh "Starting default libvirt network" \
    "virsh net-start default 2>/dev/null || true; virsh net-autostart default 2>/dev/null || true"

  if kvm-ok >/dev/null 2>&1; then ok "KVM hardware acceleration available!"; \
  else warn "KVM hardware accel not detected — VMs will use software emulation."; fi

  # 5 — Python venv
  step "[5/8] Python environment"
  mkdir -p "$INSTALL_DIR"
  rsh "Creating Python virtual environment" "python3 -m venv ${INSTALL_DIR}/venv"
  rsh "Upgrading pip, setuptools, wheel" \
    "${INSTALL_DIR}/venv/bin/pip install --quiet --upgrade pip setuptools wheel"

  rsh "Installing Flask + all panel dependencies" \
    "${INSTALL_DIR}/venv/bin/pip install --quiet \
     flask==3.0.3 flask-login==0.6.3 flask-socketio==5.3.6 \
     flask-wtf==1.2.1 werkzeug==3.0.3 \
     paramiko==3.4.0 requests==2.31.0 psutil==5.9.8 \
     python-dotenv==1.0.1 eventlet==0.36.1 \
     gevent==24.2.1 gevent-websocket==0.10.1 \
     pillow==10.3.0 qrcode==7.4.2 pyotp==2.9.0 \
     cryptography==42.0.8 aiohttp==3.9.5 \
     tinydb==4.8.0 urllib3==2.2.1 itsdangerous==2.1.2 \
     httpx==0.27.0 2>&1"

  # 6 — Copy files
  step "[6/8] Installing panel files"
  rsh "Copying panel files to $INSTALL_DIR" \
    "rsync -a --exclude='*.pyc' --exclude='__pycache__' \
     --exclude='.env' --exclude='*.db' --exclude='*.log' \
     --exclude='bot/' --exclude='venv/' \
     ${SCRIPT_DIR}/ ${INSTALL_DIR}/ 2>&1 || \
     cp -r ${SCRIPT_DIR}/. ${INSTALL_DIR}/ 2>&1 || true"

  rsh "Creating required directories" \
    "mkdir -p ${INSTALL_DIR}/static/uploads/{profiles,settings,os_icons,backups}
     mkdir -p ${INSTALL_DIR}/static/img
     mkdir -p ${INSTALL_DIR}/templates/admin
     mkdir -p ${INSTALL_DIR}/templates/errors
     mkdir -p ${INSTALL_DIR}/backups
     mkdir -p /var/lib/libvirt/images
     chmod 777 /var/lib/libvirt/images 2>/dev/null || true"

  # 7 — Config + DB init
  step "[7/8] Configuration and database"
  SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  SERVER_IP=$(curl -s --max-time 8 ifconfig.me 2>/dev/null || \
              curl -s --max-time 8 ipinfo.io/ip 2>/dev/null || \
              hostname -I | awk '{print $1}')

  cat > "${INSTALL_DIR}/.env" << ENV
PANEL_NAME=Supra Hosting
PANEL_VERSION=2.0
SECRET_KEY=${SECRET_KEY}
HOST=0.0.0.0
PORT=${PANEL_PORT}
DEBUG_MODE=False
DATABASE_PATH=${INSTALL_DIR}/supra.db
MAIN_ADMIN_USERNAME=admin
MAIN_ADMIN_PASSWORD=admin
MAIN_ADMIN_EMAIL=admin@supra.local
YOUR_SERVER_IP=${SERVER_IP}
STATS_UPDATE_INTERVAL=5
AUTO_BACKUP_INTERVAL=3600
DEFAULT_STORAGE_POOL=default
ENV

  rsh "Initializing Supra database" \
    "cd ${INSTALL_DIR} && ${INSTALL_DIR}/venv/bin/python - << 'PYEOF' 2>&1
import sys, os
sys.path.insert(0, '${INSTALL_DIR}')
os.chdir('${INSTALL_DIR}')
os.environ.setdefault('DATABASE_PATH', '${INSTALL_DIR}/supra.db')
os.environ.setdefault('MAIN_ADMIN_PASSWORD', 'admin')
os.environ.setdefault('MAIN_ADMIN_USERNAME', 'admin')
os.environ.setdefault('MAIN_ADMIN_EMAIL', 'admin@supra.local')
os.environ.setdefault('SECRET_KEY', '${SECRET_KEY}')
os.environ.setdefault('PORT', '${PANEL_PORT}')
os.environ.setdefault('DEBUG_MODE', 'False')
try:
    from lvm import init_db, migrate_discord_auth
    init_db()
    print('Database tables created.')
    migrate_discord_auth()
    print('Discord auth migration done.')
except Exception as e:
    print(f'Warning (non-fatal): {e}')
PYEOF"

  # 8 — Systemd service
  step "[8/8] Systemd service"
  cat > /etc/systemd/system/supra-panel.service << SVC
[Unit]
Description=Supra Hosting Panel (LXC + Docker + KVM)
After=network.target network-online.target libvirtd.service docker.service
Wants=network-online.target
StartLimitIntervalSec=120
StartLimitBurst=5

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${INSTALL_DIR}/.env
ExecStart=${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/lvm.py
ExecReload=/bin/kill -HUP \$MAINPID
Restart=on-failure
RestartSec=10
TimeoutStartSec=60
TimeoutStopSec=30
StandardOutput=append:${INSTALL_DIR}/supra.log
StandardError=append:${INSTALL_DIR}/supra.log
KillMode=mixed
KillSignal=SIGTERM

[Install]
WantedBy=multi-user.target
SVC

  rsh "Reloading systemd and enabling panel" \
    "systemctl daemon-reload && systemctl enable supra-panel"
  rsh "Starting Supra Panel" "systemctl restart supra-panel"

  sleep 3
  if systemctl is-active --quiet supra-panel; then ok "Panel is running!"; \
  else warn "Panel starting — check: journalctl -u supra-panel -n 30"; fi

  trap 'echo -e "\n${RED}Error on line $LINENO${RESET}"; exit 1' ERR

  echo ""
  echo -e "  ${GREEN}═══════════════════════════════════════════════════════════${RESET}"
  echo -e "  ${GREEN}  ✅  INSTALLATION COMPLETE!${RESET}"
  echo -e "  ${GREEN}═══════════════════════════════════════════════════════════${RESET}\n"
  echo -e "  ${WHITE}Panel URL:${RESET}        ${CYAN}http://${SERVER_IP}:${PANEL_PORT}${RESET}"
  echo -e "  ${WHITE}Login:${RESET}            ${CYAN}admin / admin${RESET}  ${YELLOW}← Change this!${RESET}"
  echo -e "  ${WHITE}Activate license:${RESET} ${CYAN}http://${SERVER_IP}:${PANEL_PORT}/activate-license${RESET}"
  echo -e "  ${WHITE}Log file:${RESET}         ${CYAN}${INSTALL_DIR}/supra.log${RESET}"
  echo ""
  echo -e "  ${DIM}Commands: systemctl status supra-panel | journalctl -u supra-panel -f${RESET}"
  echo -e "  ${DIM}Live logs in this installer: choose option 4${RESET}"
  echo ""
  echo -ne "  Press Enter to return to menu..."; read -r
}

install_bot() {
  print_banner
  echo -e "  ${WHITE}  DISCORD BOT SETUP${RESET}\n"
  echo -e "  ${DIM}Supports: /create lxc  /create docker  /create kvm${RESET}\n"
  echo -ne "  ${CYAN}▸${RESET}  Bot Token:               "; read -r BOT_TOKEN
  echo -ne "  ${CYAN}▸${RESET}  Your Discord User ID:    "; read -r ADMIN_ID
  echo -ne "  ${CYAN}▸${RESET}  Admin Log Channel ID:    "; read -r ADMIN_LOG
  echo -ne "  ${CYAN}▸${RESET}  Public Log Channel ID:   "; read -r PUBLIC_LOG
  echo -ne "  ${CYAN}▸${RESET}  Panel URL (http://IP:8888): "; read -r PANEL_URL_BOT
  echo -ne "  ${CYAN}▸${RESET}  Panel API Key:           "; read -r API_KEY

  mkdir -p "$BOT_DIR"
  rsh "Copying bot files" \
    "rsync -a --exclude='*.pyc' ${SCRIPT_DIR}/bot/ ${BOT_DIR}/ 2>/dev/null || \
     cp -r ${SCRIPT_DIR}/bot/. ${BOT_DIR}/ 2>/dev/null || true"

  cat > "${BOT_DIR}/.env" << ENV
BOT_TOKEN=${BOT_TOKEN}
ADMIN_IDS=${ADMIN_ID}
ADMIN_LOG_CHANNEL=${ADMIN_LOG}
PUBLIC_LOG_CHANNEL=${PUBLIC_LOG}
PANEL_URL=${PANEL_URL_BOT}
PANEL_API_KEY=${API_KEY}
PREFIX=!
ENV

  rsh "Creating bot Python environment" "python3 -m venv ${BOT_DIR}/venv"
  rsh "Installing bot dependencies" \
    "${BOT_DIR}/venv/bin/pip install --quiet \
     discord.py==2.3.2 python-dotenv==1.0.1 aiohttp==3.9.5 \
     tinydb==4.8.0 requests==2.31.0 psutil==5.9.8"

  cat > /etc/systemd/system/supra-bot.service << SVC
[Unit]
Description=Supra Hosting Discord Bot
After=network.target network-online.target
Wants=network-online.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
Type=simple
User=root
WorkingDirectory=${BOT_DIR}
EnvironmentFile=${BOT_DIR}/.env
ExecStart=${BOT_DIR}/venv/bin/python ${BOT_DIR}/bot.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVC

  rsh "Enabling and starting Discord bot" \
    "systemctl daemon-reload && systemctl enable supra-bot && systemctl restart supra-bot"

  sleep 2
  if systemctl is-active --quiet supra-bot; then ok "Discord bot is running!"; \
  else warn "Check: journalctl -u supra-bot -n 20"; fi

  echo ""
  echo -e "  ${WHITE}Bot commands:${RESET}"
  echo -e "    ${CYAN}/create lxc${RESET}      — Create LXC container"
  echo -e "    ${CYAN}/create docker${RESET}   — Create Docker (ubuntu-dind) container"
  echo -e "    ${CYAN}/create kvm${RESET}      — Create KVM virtual machine"
  echo -e "    ${CYAN}/list${RESET}            — List your servers"
  echo -e "    ${CYAN}/ssh${RESET}             — Get SSH/VNC access links"
  echo -e "    ${CYAN}/admincreate${RESET}     — Create VPS for another user"
  echo ""
  echo -ne "  Press Enter to return to menu..."; read -r
}

show_logs() {
  print_banner
  echo -e "  ${WHITE}  LIVE PANEL LOGS${RESET}"
  echo -e "  ${DIM}  File: ${INSTALL_DIR}/supra.log${RESET}"
  echo -e "  ${DIM}  Press Ctrl+C to stop${RESET}\n"
  echo -e "  ${DIM}  ─────────────────────────────────────────────────────────${RESET}"

  LOG="${INSTALL_DIR}/supra.log"
  if [ ! -f "$LOG" ]; then
    warn "Log file not found. Is the panel installed?"
    echo -e "\n  ${DIM}Checking systemd journal instead:${RESET}"
    journalctl -u supra-panel -n 50 --no-pager 2>/dev/null || true
    echo -ne "\n  Press Enter to return..."; read -r; return
  fi

  trap 'echo -e "\n\n  ${DIM}Stopped.${RESET}"; trap - INT; return' INT
  tail -n 150 -f "$LOG" 2>/dev/null | while IFS= read -r line; do
    if echo "$line" | grep -qE "ERROR|CRITICAL"; then
      echo -e "  ${RED}${line}${RESET}"
    elif echo "$line" | grep -qE "WARNING|WARN"; then
      echo -e "  ${YELLOW}${line}${RESET}"
    elif echo "$line" | grep -q " INFO "; then
      echo -e "  ${DIM}${line}${RESET}"
    else
      echo "  $line"
    fi
  done
  trap - INT
}

panel_status() {
  echo ""
  echo -e "  ${WHITE}━━ Panel Service ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  systemctl status supra-panel --no-pager -l 2>/dev/null | head -20 | sed 's/^/  /'
  echo ""
  echo -e "  ${WHITE}━━ Bot Service ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  systemctl status supra-bot --no-pager -l 2>/dev/null | head -8 | sed 's/^/  /'
  echo ""
  echo -e "  ${WHITE}━━ LXD ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  lxc list 2>/dev/null | head -10 | sed 's/^/  /' || echo "  LXD not running"
  echo ""
  echo -e "  ${WHITE}━━ Docker ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  docker ps 2>/dev/null | head -8 | sed 's/^/  /' || echo "  Docker not running"
  echo ""
  echo -e "  ${WHITE}━━ KVM / libvirt ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  virsh list --all 2>/dev/null | head -10 | sed 's/^/  /' || echo "  libvirt not running"
  echo ""
  echo -ne "  Press Enter to return..."; read -r
}

restart_panel() {
  echo -ne "\n  ${CYAN}▸${RESET}  Restarting... "
  if systemctl restart supra-panel 2>/dev/null; then
    sleep 2; systemctl is-active --quiet supra-panel \
      && echo -e "${GREEN}✓ Running${RESET}" \
      || echo -e "${YELLOW}⚠ Starting (check logs)${RESET}"
  else
    echo -e "${RED}✗ Failed — check: journalctl -u supra-panel -n 20${RESET}"
  fi
  sleep 1
}

update_panel() {
  echo ""
  echo -ne "  ${CYAN}▸${RESET}  Syncing panel files... "
  rsync -a --exclude='*.db' --exclude='.env' --exclude='*.log' \
    --exclude='*.pyc' --exclude='__pycache__' --exclude='bot/' --exclude='venv/' \
    "${SCRIPT_DIR}/" "${INSTALL_DIR}/" >>"$LOG_FILE" 2>&1 \
    && echo -e "${GREEN}✓${RESET}" || echo -e "${YELLOW}⚠${RESET}"
  echo -ne "  ${CYAN}▸${RESET}  Updating dependencies... "
  "${INSTALL_DIR}/venv/bin/pip" install --quiet -r "${INSTALL_DIR}/requirements.txt" \
    >>"$LOG_FILE" 2>&1 && echo -e "${GREEN}✓${RESET}" || echo -e "${YELLOW}⚠${RESET}"
  restart_panel
  ok "Panel updated."
  echo -ne "\n  Press Enter..."; read -r
}

do_uninstall() {
  echo -ne "\n  ${RED}⚠  Type 'yes' to uninstall: ${RESET}"; read -r c
  [ "$c" != "yes" ] && echo -e "  Cancelled." && return
  rsh "Stopping services" "systemctl stop supra-panel supra-bot 2>/dev/null; true"
  rsh "Removing services" \
    "systemctl disable supra-panel supra-bot 2>/dev/null; \
     rm -f /etc/systemd/system/supra-panel.service /etc/systemd/system/supra-bot.service; \
     systemctl daemon-reload"
  rsh "Removing install dirs" "rm -rf ${INSTALL_DIR} ${BOT_DIR}"
  ok "Uninstalled."
  echo -ne "\n  Press Enter..."; read -r
}

# Entry point
touch "$LOG_FILE" 2>/dev/null || LOG_FILE="/tmp/supra-install.log"
[ "$EUID" -ne 0 ] && echo -e "\n  ${RED}✗  Run as root: sudo bash install.sh${RESET}\n" && exit 1
. /etc/os-release 2>/dev/null || true
license_check
show_menu
